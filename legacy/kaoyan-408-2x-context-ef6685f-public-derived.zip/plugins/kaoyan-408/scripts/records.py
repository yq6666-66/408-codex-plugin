#!/usr/bin/env python3
"""Unified CLI for portable learning records (Schema 1.0 / 1.1 / 1.2).

Subcommands:
  validate   Check a record (file or ``-`` for stdin); exit 1 on invalid input.
  normalize  Upgrade 1.0/1.1 records to Schema 1.2 without fabricating evidence.
  merge      Deterministically merge two record documents without dropping data.
  due        List due review items using an explicit base date (``--date``).
  checkpoint Create, update, or read a lightweight SessionCheckpoint.

All successful output is JSON on stdout. Errors go to stderr as JSON with a
non-zero exit code (0 ok, 1 record error, 2 usage error). Standard library only.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import sys
from copy import deepcopy
from datetime import date, timedelta
from pathlib import Path
from typing import Any

SCHEMA_VERSION_CURRENT = "1.2"
SENTINELS = {"", "未提供", "unknown"}
RECORD_TYPES = {"StudyProfile", "ProgressSnapshot", "ReviewQueue", "SessionCheckpoint"}
LEGACY_RECORD_TYPES = {"StudyProfile", "ProgressSnapshot", "ReviewQueue"}
EVIDENCE_TYPES = {"independent", "hint-assisted", "solution-seen", "redo-after-solution", "transfer"}
EVIDENCE_OUTCOMES = {"correct", "incorrect", "partial", None}
MASTERY_CAPABLE = {"independent", "transfer"}
ITEM_STATUSES = {"pending", "due", "retesting", "mastered", None}
ERROR_CAUSE_STATUSES = {"confirmed", "hypothesis", None}
TEACHING_MODES = {"detailed", "hint", "independent", "mock", None}
ANSWER_STATES = {"hidden", "partial", "revealed", None}
CHECKPOINT_STATE_FIELDS = (
    "checkpointRevision", "updatedAt", "currentTask", "position", "notes",
    "teachingMode", "answerState", "hintLevel", "currentQuestion",
    "completedQuestions", "remainingQuestions", "materialVersion", "dueItems", "pendingRetests",
)
CHECKPOINT_EDIT_FIELDS = frozenset(CHECKPOINT_STATE_FIELDS) - {"checkpointRevision", "updatedAt"}
SENSITIVE_EXTENSION_KEY = re.compile(
    r"(?:^|_)(?:api_?key|api_?token|access_?token|refresh_?token|token|secret|password|passwd|"
    r"credential|authorization|cookie|email|phone|mobile|telephone|id_?card|passport|national_?id|"
    r"identity_?(?:number|no)|student_?(?:id|number)|candidate_?(?:id|number)|private_?key|user_?(?:id|name)|"
    r"account_?(?:id|name)|(?:device|local|home|file|absolute|vault)_?path|path|"
    r"(?:raw|source|question|paper)_?(?:material|text|content)|(?:real|full)_?name)(?:_|$)|^(?:name)$",
    re.IGNORECASE,
)
SENSITIVE_PATH_VALUE = re.compile(
    r"(?:\b[A-Za-z]:[\\/]|\\\\[^\\\s]+[\\/][^\\\s]+|"
    r"(?<![A-Za-z0-9:/])/(?!/)[^\s\"'<>|,;)]*)",
    re.IGNORECASE,
)
SENSITIVE_TOKEN_VALUE = re.compile(
    r"(?:\bBearer\s+\S+|\b(?:sk|ghp|github_pat|xox[baprs])[-_][A-Za-z0-9_-]{12,}|"
    r"-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----)",
    re.IGNORECASE,
)


class RecordError(RuntimeError):
    """Raised when a record document violates the portable-record contract."""


def is_plain_date(value: Any) -> bool:
    if not isinstance(value, str) or re.fullmatch(r"\d{4}-\d{2}-\d{2}", value) is None:
        return False
    try:
        date.fromisoformat(value)
    except ValueError:
        return False
    return True


def is_sentinel(value: Any) -> bool:
    return isinstance(value, str) and value.strip() in SENTINELS


def is_non_empty_string(value: Any) -> bool:
    return isinstance(value, str) and value.strip() != "" and not is_sentinel(value)


def is_non_negative_finite_number(value: Any) -> bool:
    if isinstance(value, bool):
        return False
    if isinstance(value, int):
        return value >= 0
    return isinstance(value, float) and math.isfinite(value) and value >= 0


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def stable_id(prefix: str, record: dict[str, Any]) -> str:
    digest = hashlib.sha256(canonical_json(record).encode("utf-8")).hexdigest()
    return f"{prefix}-{digest[:16]}"


def load_document(source: str) -> Any:
    if source == "-":
        payload = sys.stdin.read()
    else:
        try:
            payload = Path(source).read_text(encoding="utf-8")
        except OSError as exc:
            raise RecordError(f"cannot read input: {exc}") from exc
    try:
        return json.loads(payload)
    except json.JSONDecodeError as exc:
        raise RecordError(f"input is not valid JSON: {exc}") from exc


def as_record_list(document: Any) -> list[dict[str, Any]]:
    if isinstance(document, list):
        items = document
    elif isinstance(document, dict) and isinstance(document.get("records"), list):
        items = document["records"]
    else:
        items = [document]
    for item in items:
        if not isinstance(item, dict):
            raise RecordError("every record must be a JSON object")
    return items


def emit(document: Any) -> None:
    print(json.dumps(document, ensure_ascii=False, indent=2, sort_keys=False))


def _legacy_record_type_candidates(record: dict[str, Any]) -> list[str]:
    candidates: list[str] = []
    if any(key in record for key in (
        "targetExam", "targetDate", "weeklyHours", "currentPhase", "constraints",
    )):
        candidates.append("StudyProfile")
    if any(key in record for key in (
        "period", "plannedUnits", "completedUnits", "accuracy", "sampleSize", "bySubject", "blockers",
    )):
        candidates.append("ProgressSnapshot")
    if "items" in record:
        candidates.append("ReviewQueue")
    return candidates


def infer_record_type_10(record: dict[str, Any]) -> str | None:
    candidates = _legacy_record_type_candidates(record)
    if len(candidates) > 1:
        raise RecordError(
            "ambiguous Schema 1.0 recordType: signatures match "
            + ", ".join(candidates)
            + "; keep one type's identifying fields or split the records before migration"
        )
    return candidates[0] if candidates else None


def _convert_sentinels(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _convert_sentinels(item) for key, item in value.items()}
    if isinstance(value, list):
        converted = [_convert_sentinels(item) for item in value]
        if any(is_sentinel(item) for item in value):
            return [item for item in converted if not is_sentinel(item)]
        return converted
    if is_sentinel(value):
        return None
    return value


def _contains_sentinel(value: Any) -> bool:
    if isinstance(value, dict):
        return any(_contains_sentinel(item) for item in value.values())
    if isinstance(value, list):
        return any(_contains_sentinel(item) for item in value)
    return is_sentinel(value)


def _pointer_escape(value: str) -> str:
    return value.replace("~", "~0").replace("/", "~1")


def _is_sensitive_extension_key(key: str) -> bool:
    separated = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", key)
    normalized = re.sub(r"[^A-Za-z0-9]+", "_", separated).strip("_")
    return bool(SENSITIVE_EXTENSION_KEY.search(normalized))


def _redact_legacy_extensions(
    extensions: dict[str, Any], *, base_pointer: str = "/legacyExtensions"
) -> tuple[dict[str, Any], list[str]]:
    redacted: list[str] = []

    def scrub(value: Any, pointer: str) -> Any:
        if isinstance(value, dict):
            output: dict[str, Any] = {}
            for raw_key, child in value.items():
                key = str(raw_key)
                child_pointer = f"{pointer}/{_pointer_escape(key)}"
                if _is_sensitive_extension_key(key):
                    output[raw_key] = None
                    redacted.append(child_pointer)
                else:
                    output[raw_key] = scrub(child, child_pointer)
            return output
        if isinstance(value, list):
            return [scrub(child, f"{pointer}/{index}") for index, child in enumerate(value)]
        if isinstance(value, str) and (
            SENSITIVE_PATH_VALUE.search(value) or SENSITIVE_TOKEN_VALUE.search(value)
        ):
            redacted.append(pointer)
            return None
        return value

    cleaned = {
        key: None if _is_sensitive_extension_key(key) else scrub(value, f"{base_pointer}/{_pointer_escape(key)}")
        for key, value in extensions.items()
    }
    for key in extensions:
        if _is_sensitive_extension_key(key):
            redacted.append(f"{base_pointer}/{_pointer_escape(key)}")
    return cleaned, sorted(set(redacted))


def _redact_schema_11_extensions(record: dict[str, Any]) -> list[str]:
    """Redact sensitive extension keys while preserving safe 1.1 fields in place."""
    redacted: list[str] = []

    def scrub(obj: dict[str, Any], known: set[str], pointer: str) -> None:
        extensions = {key: value for key, value in obj.items() if key not in known}
        if extensions:
            cleaned, fields = _redact_legacy_extensions(extensions, base_pointer=pointer)
            obj.update(cleaned)
            redacted.extend(fields)

    root_known = {
        "schemaVersion", "recordType", "recordId", "updatedAt", "redactedFields",
        "legacyExtensions", "migrationWarnings",
    }
    record_type = record.get("recordType")
    root_known.update({
        "StudyProfile": {
            "targetExam", "targetDate", "weeklyHours", "currentPhase", "constraints",
        },
        "ProgressSnapshot": {"period", "metrics", "accuracy", "blockers"},
        "ReviewQueue": {"generatedAt", "items"},
        "SessionCheckpoint": {
            "checkpointId", "checkpointRevision", "updatedAt", "currentTask", "position", "dueItems",
            "pendingRetests", "notes", "teachingMode", "answerState", "hintLevel",
            "currentQuestion", "completedQuestions", "remainingQuestions", "materialVersion",
        },
    }.get(record_type, set()))
    scrub(record, root_known, "")

    composite_fields = {
        "ProgressSnapshot": {
            "period": {"start", "end"},
            "metrics": {"subject", "name", "unit", "planned", "completed"},
            "accuracy": {"subject", "correct", "total", "rate"},
        },
        "ReviewQueue": {
            "items": {
                "subject", "topic", "errorCause", "errorCauseStatus", "nextRetestDate",
                "retestOffsetDays", "retestAnchorDate", "itemId", "status",
                "masteryEvidence", "retestEvidence",
            },
        },
    }.get(record_type, {})
    for field, known in composite_fields.items():
        value = record.get(field)
        if isinstance(value, dict):
            scrub(value, known, f"/{_pointer_escape(field)}")
        elif isinstance(value, list):
            for index, entry in enumerate(value):
                if isinstance(entry, dict):
                    pointer = f"/{_pointer_escape(field)}/{index}"
                    scrub(entry, known, pointer)
                    if record_type == "ReviewQueue" and field == "items":
                        evidence = entry.get("retestEvidence")
                        if isinstance(evidence, list):
                            evidence_fields = {"evidenceType", "outcome", "date", "note"}
                            for evidence_index, evidence_entry in enumerate(evidence):
                                if isinstance(evidence_entry, dict):
                                    scrub(
                                        evidence_entry,
                                        evidence_fields,
                                        f"{pointer}/retestEvidence/{evidence_index}",
                                    )

    legacy_extensions = record.get("legacyExtensions")
    if isinstance(legacy_extensions, dict):
        cleaned, fields = _redact_legacy_extensions(legacy_extensions)
        record["legacyExtensions"] = cleaned
        redacted.extend(fields)
    return sorted(set(redacted))


def normalize_10_to_11(record: dict[str, Any]) -> tuple[dict[str, Any], list[str]]:
    warnings: list[str] = []
    validation_errors = validate_legacy_10(record)
    if validation_errors:
        raise RecordError("invalid Schema 1.0 record: " + "; ".join(validation_errors))
    if _contains_sentinel(record):
        warnings.append(
            "legacy sentinel values (empty string / 未提供 / unknown) converted to null or empty arrays"
        )
    record_type = record.get("recordType")
    if not record_type:
        record_type = infer_record_type_10(record)
    if record_type is None:
        raise RecordError("cannot infer recordType from a Schema 1.0 object")
    converted: dict[str, Any] = {
        "schemaVersion": "1.1",
        "recordType": record_type,
    }
    unknown: dict[str, Any] = {}
    redacted_fields: list[str] = []
    extension_conflicts: dict[str, Any] = {}
    known_keys_by_type = {
        "StudyProfile": {"targetExam", "targetDate", "weeklyHours", "currentPhase", "constraints"},
        "ProgressSnapshot": {
            "period", "plannedUnits", "completedUnits", "accuracy", "sampleSize",
            "bySubject", "blockers", "unit",
        },
        "ReviewQueue": {"items", "generatedAt"},
    }
    known_keys = {"recordType"} | known_keys_by_type.get(record_type, set())
    for key, value in record.items():
        if key == "schemaVersion" or key in known_keys:
            continue
        unknown[key] = value
    if record_type == "StudyProfile":
        converted["targetExam"] = _convert_sentinels(record.get("targetExam"))
        converted["targetDate"] = _convert_sentinels(record.get("targetDate"))
        converted["weeklyHours"] = _convert_sentinels(record.get("weeklyHours"))
        converted["currentPhase"] = _convert_sentinels(record.get("currentPhase"))
        constraints = record.get("constraints")
        converted["constraints"] = (
            [item for item in constraints if not is_sentinel(item)]
            if isinstance(constraints, list)
            else []
        )
    elif record_type == "ProgressSnapshot":
        period = record.get("period")
        converted_period = {
            "start": _convert_sentinels(period.get("start")) if isinstance(period, dict) else None,
            "end": _convert_sentinels(period.get("end")) if isinstance(period, dict) else None,
        }
        if isinstance(period, dict):
            period_extensions = {key: value for key, value in period.items() if key not in {"start", "end"}}
            if period_extensions:
                safe_extensions, extension_redactions = _redact_legacy_extensions(
                    period_extensions, base_pointer="/period"
                )
                converted_period.update({
                    key: _convert_sentinels(value) for key, value in safe_extensions.items()
                })
                redacted_fields.extend(extension_redactions)
                warnings.append(
                    "unknown legacy period fields preserved: " + ", ".join(sorted(period_extensions))
                )
        converted["period"] = converted_period
        metrics: list[dict[str, Any]] = []
        accuracy_entries: list[dict[str, Any]] = []
        if "plannedUnits" in record or "completedUnits" in record:
            raw_unit = _convert_sentinels(record.get("unit")) if "unit" in record else None
            unit_is_valid = is_non_empty_string(raw_unit)
            unit = raw_unit if unit_is_valid else "unspecified"
            metrics.append({
                "subject": None,
                "name": "overall",
                "unit": unit,
                "planned": _convert_sentinels(record.get("plannedUnits")),
                "completed": _convert_sentinels(record.get("completedUnits")),
            })
            if not unit_is_valid:
                warnings.append("root plannedUnits/completedUnits carry no unit; using 'unspecified'")
        by_subject = record.get("bySubject")
        if isinstance(by_subject, list):
            for subject_index, entry in enumerate(by_subject):
                if not isinstance(entry, dict):
                    continue
                raw_subject_unit = (
                    _convert_sentinels(entry.get("unit")) if "unit" in entry else None
                )
                subject_unit_is_valid = is_non_empty_string(raw_subject_unit)
                subject_unit = raw_subject_unit if subject_unit_is_valid else "unspecified"
                if "unit" in entry and not subject_unit_is_valid:
                    warnings.append(
                        f"legacy bySubject[{subject_index}].unit has no usable value; "
                        "using 'unspecified'"
                    )
                metrics.append({
                    "subject": _convert_sentinels(entry.get("subject")),
                    "name": "workload",
                    "unit": subject_unit,
                    "planned": _convert_sentinels(entry.get("plannedUnits")),
                    "completed": _convert_sentinels(entry.get("completedUnits")),
                })
                if "accuracy" in entry or "sampleSize" in entry:
                    subject_accuracy = _convert_sentinels(entry.get("accuracy"))
                    subject_sample_size = _convert_sentinels(entry.get("sampleSize"))
                    accuracy_entries.append({
                        "subject": _convert_sentinels(entry.get("subject")),
                        "correct": None,
                        "total": subject_sample_size,
                        "rate": subject_accuracy,
                    })
                    if subject_accuracy is not None and subject_sample_size is None:
                        warnings.append(
                            "legacy bySubject accuracy has no sampleSize; total set to null"
                        )
        converted["metrics"] = metrics
        accuracy_value = _convert_sentinels(record.get("accuracy"))
        sample_size = _convert_sentinels(record.get("sampleSize"))
        if "accuracy" in record or "sampleSize" in record:
            accuracy_entries.append({
                "subject": None,
                "correct": None,
                "total": sample_size,
                "rate": accuracy_value,
            })
            if accuracy_value is not None and sample_size is None:
                warnings.append("legacy accuracy has no sampleSize; total set to null")
        converted["accuracy"] = accuracy_entries
        blockers = record.get("blockers")
        converted["blockers"] = (
            [item for item in blockers if not is_sentinel(item)]
            if isinstance(blockers, list)
            else []
        )
    else:
        converted["generatedAt"] = _convert_sentinels(record.get("generatedAt"))
        items: list[dict[str, Any]] = []
        raw_items = record.get("items")
        if "items" in record and not isinstance(raw_items, list):
            raise RecordError("items must be an array")
        for index, entry in enumerate(raw_items if isinstance(raw_items, list) else []):
            if not isinstance(entry, dict):
                raise RecordError(f"items[{index}] must be an object")
            retest_date = entry.get("retestDate")
            item: dict[str, Any] = {
                "subject": _convert_sentinels(entry.get("subject")),
                "topic": _convert_sentinels(entry.get("topic")),
                "errorCause": _convert_sentinels(entry.get("errorCause")),
                "errorCauseStatus": _convert_sentinels(entry.get("errorCauseStatus")),
                "nextRetestDate": _convert_sentinels(entry.get("nextRetestDate")),
                "retestOffsetDays": _convert_sentinels(entry.get("retestOffsetDays")),
                "retestAnchorDate": _convert_sentinels(entry.get("retestAnchorDate")),
                "status": _convert_sentinels(entry.get("status")),
                "masteryEvidence": [],
            }
            has_forward_schedule = "nextRetestDate" in entry or "retestOffsetDays" in entry
            if not has_forward_schedule:
                if isinstance(retest_date, str) and retest_date.strip().upper().startswith("D+"):
                    try:
                        offset = int(retest_date.strip()[2:])
                        if offset < 0:
                            warnings.append(
                                f"negative legacy retestDate {retest_date!r} kept as null"
                            )
                        else:
                            item["retestOffsetDays"] = offset
                    except ValueError:
                        warnings.append(f"unparseable legacy retestDate {retest_date!r} kept as null")
                elif is_plain_date(retest_date):
                    item["nextRetestDate"] = retest_date
                elif retest_date is not None:
                    warnings.append(f"legacy retestDate {retest_date!r} is neither D+N nor a date; set to null")
            evidence = entry.get("masteryEvidence")
            item["masteryEvidence"] = (
                [text for text in evidence if not is_sentinel(text)]
                if isinstance(evidence, list)
                else []
            )
            known_item_fields = {
                "subject", "topic", "errorCause", "errorCauseStatus", "nextRetestDate",
                "retestOffsetDays", "retestAnchorDate", "status", "masteryEvidence",
            }
            unknown_item_fields = {
                key: value for key, value in entry.items() if key not in known_item_fields
            }
            if unknown_item_fields:
                pointer_base = f"/items/{index}"
                safe_item_fields, item_redacted = _redact_legacy_extensions(
                    unknown_item_fields, base_pointer=pointer_base
                )
                redacted_fields.extend(item_redacted)
                redacted_item_keys = {
                    pointer[len(pointer_base) + 1:].replace("~1", "/").replace("~0", "~").split("/", 1)[0]
                    for pointer in item_redacted
                    if pointer.startswith(pointer_base + "/")
                }
                for key, value in safe_item_fields.items():
                    if key in item:
                        if key not in redacted_item_keys:
                            extension_conflicts[f"{pointer_base}/{_pointer_escape(key)}"] = value
                    else:
                        item[key] = value
            items.append(item)
        converted["items"] = items
    if unknown:
        safe_root_extensions, root_redacted = _redact_legacy_extensions(unknown)
        redacted_fields.extend(root_redacted)
        converted["legacyExtensions"] = safe_root_extensions
        warnings.append(
            "unknown legacy fields preserved under legacyExtensions: "
            + ", ".join(sorted(unknown))
        )
    if extension_conflicts:
        converted.setdefault("legacyExtensions", {}).update(extension_conflicts)
        warnings.append("conflicting legacy item extensions preserved under legacyExtensions by JSON Pointer")
    if redacted_fields:
        converted["redactedFields"] = sorted(set(redacted_fields))
        warnings.append("sensitive legacy extension values redacted at: " + ", ".join(sorted(set(redacted_fields))))
    return converted, warnings


def normalize_to_12(record: dict[str, Any]) -> tuple[dict[str, Any], list[str]]:
    """Normalize a 1.0/1.1/1.2 record to Schema 1.2. Idempotent and evidence-safe."""
    warnings: list[str] = []
    converted = json.loads(canonical_json(record))
    version = converted.get("schemaVersion")
    if version not in {"1.0", "1.1", "1.2"}:
        raise RecordError(f"unsupported schemaVersion for normalization: {version!r}")
    if version == "1.0":
        converted, migrate_warnings = normalize_10_to_11(converted)
        warnings.extend(migrate_warnings)
    else:
        validation_record = converted
        if version == "1.1" and converted.get("recordType") == "SessionCheckpoint":
            validation_record = {**converted, "schemaVersion": "1.2"}
        errors, _ = validate_current(validation_record)
        if errors:
            raise RecordError("invalid Schema " + str(version) + " record: " + "; ".join(errors))
    if version == "1.1":
        redacted = _redact_schema_11_extensions(converted)
        if redacted:
            previous = converted.get("redactedFields")
            previous_fields = previous if isinstance(previous, list) else []
            converted["redactedFields"] = sorted({
                field for field in [*previous_fields, *redacted] if isinstance(field, str)
            })
            warnings.append(
                "sensitive Schema 1.1 extension values redacted at: " + ", ".join(redacted)
            )
    record_type = converted.get("recordType")
    if record_type not in RECORD_TYPES:
        raise RecordError(f"unknown recordType: {record_type!r}")
    converted["schemaVersion"] = SCHEMA_VERSION_CURRENT
    if record_type != "SessionCheckpoint" and not converted.get("recordId"):
        converted["recordId"] = stable_id("kr", record)
    if "updatedAt" not in converted:
        converted["updatedAt"] = None
    if record_type == "ReviewQueue":
        items = converted.get("items", [])
        if not isinstance(items, list):
            raise RecordError("items must be an array")
        for index, item in enumerate(items):
            if not isinstance(item, dict):
                raise RecordError(f"items[{index}] must be an object")
            if "retestEvidence" not in item:
                item["retestEvidence"] = []
            if "itemId" not in item:
                item["itemId"] = stable_id("kr", {**item, "_index": index})
            if item.get("status") == "mastered":
                warnings.extend(
                    f"items[{index}]: {message}"
                    for message in mastery_warnings(item, index)
                )
    if record_type == "SessionCheckpoint" and not converted.get("checkpointId"):
        converted["checkpointId"] = stable_id("kc", record)
    if record == converted:
        return converted, warnings
    return converted, warnings


def mastery_warnings(item: dict[str, Any], index: int) -> list[str]:
    if item.get("status") != "mastered":
        return []
    evidence = item.get("retestEvidence")
    if isinstance(evidence, list) and any(
        isinstance(entry, dict)
        and entry.get("evidenceType") in MASTERY_CAPABLE
        and entry.get("outcome") == "correct"
        for entry in evidence
    ):
        return []
    return ["status is mastered without independent or transfer retest evidence"]


def _require(record: dict[str, Any], key: str, errors: list[str]) -> None:
    if key not in record:
        errors.append(f"missing required field: {key}")


def _array_or_empty(record: dict[str, Any], key: str, errors: list[str]) -> list[Any]:
    if key not in record:
        return []
    value = record[key]
    if not isinstance(value, list):
        errors.append(f"{key} must be an array")
        return []
    return value


def _check_nullable_string(record: dict[str, Any], key: str, errors: list[str]) -> None:
    value = record.get(key)
    if value is None:
        return
    if not is_non_empty_string(value):
        errors.append(f"{key} must be a non-empty string or null, got {value!r}")


def _check_date(record: dict[str, Any], key: str, errors: list[str]) -> None:
    value = record.get(key)
    if value is None:
        return
    if not is_plain_date(value):
        errors.append(f"{key} must be a YYYY-MM-DD date or null, got {value!r}")


def _legacy_nullable_string(value: Any) -> bool:
    return value is None or is_sentinel(value) or isinstance(value, str)


def _legacy_nullable_date(value: Any) -> bool:
    return value is None or is_sentinel(value) or is_plain_date(value)


def _legacy_nullable_number(value: Any) -> bool:
    return value is None or is_sentinel(value) or is_non_negative_finite_number(value)


def _legacy_nullable_integer(value: Any) -> bool:
    return value is None or is_sentinel(value) or (
        isinstance(value, int) and not isinstance(value, bool) and value >= 0
    )


def _legacy_nullable_rate(value: Any) -> bool:
    return value is None or is_sentinel(value) or (
        isinstance(value, (int, float)) and not isinstance(value, bool) and 0 <= value <= 1
    )


def validate_legacy_10(record: dict[str, Any]) -> list[str]:
    """Validate the supported Schema 1.0 shapes before labeling them readable."""
    errors: list[str] = []
    record_type = record.get("recordType")
    if not record_type:
        try:
            record_type = infer_record_type_10(record)
        except RecordError as exc:
            return [str(exc)]
    if record_type not in LEGACY_RECORD_TYPES:
        return ["Schema 1.0 record has no recognizable legacy record type"]

    if record_type == "StudyProfile":
        if "targetExam" not in record:
            errors.append("missing required field: targetExam")
        for key in ("targetExam", "currentPhase"):
            if key in record and not _legacy_nullable_string(record[key]):
                errors.append(f"{key} must be a legacy nullable string")
        if "targetDate" in record and not _legacy_nullable_date(record["targetDate"]):
            errors.append("targetDate must be a legacy nullable date")
        if "weeklyHours" in record and not _legacy_nullable_number(record["weeklyHours"]):
            errors.append("weeklyHours must be a non-negative legacy number or sentinel")
        if "constraints" in record:
            value = record["constraints"]
            if (
                value is not None
                and not (isinstance(value, list) and all(isinstance(entry, str) for entry in value))
                and not is_sentinel(value)
            ):
                errors.append("constraints must be a legacy string array or sentinel")
    elif record_type == "ProgressSnapshot":
        source_fields = ("period", "plannedUnits", "completedUnits", "accuracy", "sampleSize", "bySubject", "blockers")
        if not any(key in record for key in source_fields):
            errors.append("Schema 1.0 ProgressSnapshot requires at least one progress field")
        if "period" in record:
            period = record["period"]
            if not isinstance(period, dict):
                errors.append("period must be an object")
            else:
                for key in ("start", "end"):
                    if key in period and not _legacy_nullable_date(period[key]):
                        errors.append(f"period.{key} must be a legacy nullable date")
        for key in ("plannedUnits", "completedUnits"):
            if key in record and not _legacy_nullable_number(record[key]):
                errors.append(f"{key} must be a non-negative legacy number or sentinel")
        if "accuracy" in record and not _legacy_nullable_rate(record["accuracy"]):
            errors.append("accuracy must be a legacy nullable rate")
        if "sampleSize" in record and not _legacy_nullable_integer(record["sampleSize"]):
            errors.append("sampleSize must be a non-negative legacy integer or sentinel")
        if "bySubject" in record:
            entries = record["bySubject"]
            if not isinstance(entries, list):
                errors.append("bySubject must be an array")
            else:
                for index, entry in enumerate(entries):
                    if not isinstance(entry, dict):
                        errors.append(f"bySubject[{index}] must be an object")
                        continue
                    for key in ("subject",):
                        if key in entry and not _legacy_nullable_string(entry[key]):
                            errors.append(f"bySubject[{index}].{key} must be a legacy nullable string")
                    if "unit" in entry and not _legacy_nullable_string(entry["unit"]):
                        errors.append(f"bySubject[{index}].unit must be a legacy nullable string")
                    for key in ("plannedUnits", "completedUnits"):
                        if key in entry and not _legacy_nullable_number(entry[key]):
                            errors.append(f"bySubject[{index}].{key} must be a non-negative legacy number or sentinel")
                    if "accuracy" in entry and not _legacy_nullable_rate(entry["accuracy"]):
                        errors.append(f"bySubject[{index}].accuracy must be a legacy nullable rate")
                    if "sampleSize" in entry and not _legacy_nullable_integer(entry["sampleSize"]):
                        errors.append(f"bySubject[{index}].sampleSize must be a non-negative legacy integer or sentinel")
        if "blockers" in record:
            value = record["blockers"]
            if (
                value is not None
                and not (isinstance(value, list) and all(isinstance(entry, str) for entry in value))
                and not is_sentinel(value)
            ):
                errors.append("blockers must be a legacy string array or sentinel")
    else:  # ReviewQueue
        if "items" not in record:
            errors.append("missing required field: items")
        elif not isinstance(record["items"], list):
            errors.append("items must be an array")
        else:
            for index, item in enumerate(record["items"]):
                if not isinstance(item, dict):
                    errors.append(f"items[{index}] must be an object")
                    continue
                for key in ("subject", "topic", "errorCause", "status", "retestDate"):
                    if key in item and not _legacy_nullable_string(item[key]):
                        errors.append(f"items[{index}].{key} must be a legacy nullable string")
                if "masteryEvidence" in item:
                    value = item["masteryEvidence"]
                    if (
                        value is not None
                        and not (isinstance(value, list) and all(isinstance(entry, str) for entry in value))
                        and not is_sentinel(value)
                    ):
                        errors.append(f"items[{index}].masteryEvidence must be a legacy string array or sentinel")
        if "generatedAt" in record and not _legacy_nullable_date(record["generatedAt"]):
            errors.append("generatedAt must be a legacy nullable date")
    return errors


def validate_current(record: dict[str, Any]) -> tuple[list[str], list[str]]:
    """Hand-rolled structural validation for Schema 1.1/1.2 records."""
    errors: list[str] = []
    warnings: list[str] = []
    record_type = record.get("recordType")
    version = record.get("schemaVersion")
    if record_type not in RECORD_TYPES or record_type == "SessionCheckpoint" and version != "1.2":
        errors.append(f"unsupported recordType/schemaVersion: {record_type!r}/{version!r}")
        return errors, warnings
    if version not in {"1.1", "1.2"}:
        errors.append(f"schemaVersion must be 1.1 or 1.2 at the root, got {version!r}")
        return errors, warnings
    if "recordId" in record:
        rid = record["recordId"]
        if not isinstance(rid, str) or re.fullmatch(r"kr-[0-9a-f]{16}", rid) is None:
            errors.append(f"recordId must match kr- plus 16 lowercase hex digits, got {rid!r}")
    _check_date(record, "updatedAt", errors)
    if "redactedFields" in record:
        redacted_fields = record["redactedFields"]
        if not isinstance(redacted_fields, list) or any(
            not is_non_empty_string(entry) for entry in redacted_fields
        ):
            errors.append("redactedFields must be an array of non-empty strings")
        elif len(set(redacted_fields)) != len(redacted_fields):
            errors.append("redactedFields must not contain duplicates")
    if "legacyExtensions" in record and not isinstance(record["legacyExtensions"], dict):
        errors.append("legacyExtensions must be an object")
    if "migrationWarnings" in record:
        migration_warnings = record["migrationWarnings"]
        if not isinstance(migration_warnings, list) or any(
            not is_non_empty_string(entry) for entry in migration_warnings
        ):
            errors.append("migrationWarnings must be an array of non-empty strings")

    if record_type == "StudyProfile":
        for key in ("targetExam", "targetDate", "weeklyHours", "currentPhase", "constraints"):
            _require(record, key, errors)
        _check_nullable_string(record, "targetExam", errors)
        _check_date(record, "targetDate", errors)
        _check_nullable_string(record, "currentPhase", errors)
        constraints = record.get("constraints")
        if not isinstance(constraints, list):
            errors.append("constraints must be an array")
        else:
            for index, constraint in enumerate(constraints):
                if not is_non_empty_string(constraint):
                    errors.append(f"constraints[{index}] must be a non-empty string")
        weekly = record.get("weeklyHours")
        if weekly is not None and not is_non_negative_finite_number(weekly):
            errors.append("weeklyHours must be a non-negative number or null")
    elif record_type == "ProgressSnapshot":
        for key in ("period", "metrics", "accuracy", "blockers"):
            _require(record, key, errors)
        period = record.get("period")
        if not isinstance(period, dict):
            errors.append("period must be an object")
        else:
            for key in ("start", "end"):
                if key not in period:
                    errors.append(f"period.{key} is required")
                    continue
                value = period[key]
                if value is not None and not is_plain_date(value):
                    errors.append(f"period.{key} must be a YYYY-MM-DD date or null, got {value!r}")
        for index, entry in enumerate(_array_or_empty(record, "metrics", errors)):
            if not isinstance(entry, dict):
                errors.append(f"metrics[{index}] must be an object")
                continue
            for key in ("subject", "name", "unit", "planned", "completed"):
                if key not in entry:
                    errors.append(f"metrics[{index}] missing {key}")
            if not is_non_empty_string(entry.get("unit", "")):
                errors.append(f"metrics[{index}].unit must be a non-empty string")
            for key in ("subject", "name"):
                value = entry.get(key)
                if value is not None and not is_non_empty_string(value):
                    errors.append(f"metrics[{index}].{key} must be a non-empty string or null")
            for key in ("planned", "completed"):
                value = entry.get(key)
                if value is not None and not is_non_negative_finite_number(value):
                    errors.append(f"metrics[{index}].{key} must be a non-negative number or null")
        for index, entry in enumerate(_array_or_empty(record, "accuracy", errors)):
            if not isinstance(entry, dict):
                errors.append(f"accuracy[{index}] must be an object")
                continue
            for key in ("subject", "correct", "total", "rate"):
                if key not in entry:
                    errors.append(f"accuracy[{index}] missing {key}")
            if "subject" in entry:
                subject = entry["subject"]
                if subject is not None and not is_non_empty_string(subject):
                    errors.append(f"accuracy[{index}].subject must be a non-empty string or null")
            correct, total, rate = entry.get("correct"), entry.get("total"), entry.get("rate")
            correct_valid = correct is None or (
                isinstance(correct, int) and not isinstance(correct, bool) and correct >= 0
            )
            total_valid = total is None or (
                isinstance(total, int) and not isinstance(total, bool) and total >= 0
            )
            rate_valid = rate is None or (
                isinstance(rate, (int, float)) and not isinstance(rate, bool) and 0 <= rate <= 1
            )
            if not correct_valid:
                errors.append(f"accuracy[{index}].correct must be a non-negative integer or null")
            if not total_valid:
                errors.append(f"accuracy[{index}].total must be a non-negative integer or null")
            if not rate_valid:
                errors.append(f"accuracy[{index}].rate must be a number from 0 to 1 or null")
            if correct_valid and total_valid and correct is not None and total is not None and correct > total:
                errors.append(f"accuracy[{index}].correct must not exceed total")
            if total_valid and total == 0:
                if correct not in {None, 0}:
                    errors.append(f"accuracy[{index}].correct must be 0 or null when total is zero")
                if rate is not None:
                    errors.append(f"accuracy[{index}].rate must be null when total is zero")
            elif correct_valid and total_valid and rate_valid and correct is not None and total is not None and rate is not None:
                if abs(rate - correct / total) > 1e-9:
                    errors.append(f"accuracy[{index}].rate must equal correct / total")
        blockers = record.get("blockers")
        if not isinstance(blockers, list):
            errors.append("blockers must be an array")
        else:
            for index, blocker in enumerate(blockers):
                if not is_non_empty_string(blocker):
                    errors.append(f"blockers[{index}] must be a non-empty string")
    elif record_type == "ReviewQueue":
        for key in ("generatedAt", "items"):
            _require(record, key, errors)
        _check_date(record, "generatedAt", errors)
        for index, item in enumerate(_array_or_empty(record, "items", errors)):
            if not isinstance(item, dict):
                errors.append(f"items[{index}] must be an object")
                continue
            for key in ("subject", "topic", "errorCause", "errorCauseStatus",
                        "nextRetestDate", "retestOffsetDays", "status", "masteryEvidence"):
                if key not in item:
                    errors.append(f"items[{index}] missing {key}")
            for key in ("subject", "topic", "errorCause"):
                if key in item:
                    _check_nullable_string(item, key, errors)
            if "itemId" in item and (
                not isinstance(item["itemId"], str)
                or re.fullmatch(r"kr-[0-9a-f]{16}", item["itemId"]) is None
            ):
                errors.append(f"items[{index}].itemId must match kr- plus 16 lowercase hex digits")
            for key in ("nextRetestDate", "retestAnchorDate"):
                _check_date(item, key, errors)
            if item.get("errorCauseStatus") not in ERROR_CAUSE_STATUSES:
                errors.append(f"items[{index}].errorCauseStatus is invalid: {item.get('errorCauseStatus')!r}")
            if item.get("status") not in ITEM_STATUSES:
                errors.append(f"items[{index}].status is invalid: {item.get('status')!r}")
            offset, anchor = item.get("retestOffsetDays"), item.get("retestAnchorDate")
            offset_is_valid = offset is None or (
                isinstance(offset, int) and not isinstance(offset, bool) and offset >= 0
            )
            if not offset_is_valid:
                errors.append(f"items[{index}].retestOffsetDays must be a non-negative integer or null")
            if is_plain_date(item.get("nextRetestDate", None)) and offset is not None:
                errors.append(
                    f"items[{index}] must not carry nextRetestDate and retestOffsetDays simultaneously"
                )
            if isinstance(offset, int) and not isinstance(offset, bool) and offset >= 0 and not is_plain_date(anchor):
                warnings.append(
                    f"items[{index}] has retestOffsetDays without retestAnchorDate; "
                    "due requires an explicit base date"
                )
            if not isinstance(item.get("masteryEvidence"), list):
                errors.append(f"items[{index}].masteryEvidence must be an array")
            else:
                for evidence_index, entry in enumerate(item["masteryEvidence"]):
                    if not is_non_empty_string(entry):
                        errors.append(
                            f"items[{index}].masteryEvidence[{evidence_index}] must be a non-empty string"
                        )
            evidence = item.get("retestEvidence", [])
            if not isinstance(evidence, list):
                errors.append(f"items[{index}].retestEvidence must be an array")
            else:
                for position, entry in enumerate(evidence):
                    if not isinstance(entry, dict):
                        errors.append(f"items[{index}].retestEvidence[{position}] must be an object")
                        continue
                    if entry.get("evidenceType") not in EVIDENCE_TYPES:
                        errors.append(
                            f"items[{index}].retestEvidence[{position}].evidenceType is invalid"
                        )
                    if "outcome" not in entry:
                        errors.append(
                            f"items[{index}].retestEvidence[{position}].outcome is required"
                        )
                    elif entry["outcome"] not in EVIDENCE_OUTCOMES:
                        errors.append(
                            f"items[{index}].retestEvidence[{position}].outcome is invalid"
                        )
                    if "note" in entry:
                        _check_nullable_string(entry, "note", errors)
                    entry_date = entry.get("date")
                    if entry_date is not None and not is_plain_date(entry_date):
                        errors.append(
                            f"items[{index}].retestEvidence[{position}].date must be YYYY-MM-DD or null"
                        )
            warnings.extend(
                f"items[{index}]: {message}" for message in mastery_warnings(item, index)
            )
    else:  # SessionCheckpoint
        for key in ("updatedAt", "currentTask", "position", "dueItems", "pendingRetests"):
            _require(record, key, errors)
        if "checkpointRevision" in record:
            revision = record["checkpointRevision"]
            if isinstance(revision, bool) or not isinstance(revision, int) or revision < 1:
                errors.append("checkpointRevision must be a positive integer")
        if "checkpointId" in record and (
            not isinstance(record["checkpointId"], str)
            or re.fullmatch(r"kc-[0-9a-f]{16}", record["checkpointId"]) is None
        ):
            errors.append("checkpointId must match kc- plus 16 lowercase hex digits")
        for key in ("dueItems", "pendingRetests"):
            value = record.get(key)
            if not (isinstance(value, list) and all(is_non_empty_string(entry) for entry in value)):
                errors.append(f"{key} must be an array of non-empty non-sentinel strings")
        if record.get("teachingMode") not in TEACHING_MODES:
            errors.append("teachingMode must be detailed, hint, independent, mock, or null")
        if record.get("answerState") not in ANSWER_STATES:
            errors.append("answerState must be hidden, partial, revealed, or null")
        hint_level = record.get("hintLevel")
        if hint_level is not None and (
            isinstance(hint_level, bool) or not isinstance(hint_level, int) or not 0 <= hint_level <= 3
        ):
            errors.append("hintLevel must be an integer from 0 to 3 or null")
        for key in ("currentQuestion", "materialVersion", "notes"):
            _check_nullable_string(record, key, errors)
        for key in ("currentTask", "position"):
            _check_nullable_string(record, key, errors)
        question_sets: dict[str, set[str]] = {}
        for key in ("completedQuestions", "remainingQuestions"):
            if key not in record:
                continue
            value = record[key]
            valid_questions = (
                isinstance(value, list)
                and all(is_non_empty_string(entry) for entry in value)
                and len(value) == len(set(value))
            )
            if not valid_questions:
                errors.append(f"{key} must be an array of unique non-empty strings")
            else:
                question_sets[key] = set(value)
        if (
            "completedQuestions" in question_sets
            and "remainingQuestions" in question_sets
            and question_sets["completedQuestions"] & question_sets["remainingQuestions"]
        ):
            errors.append("completedQuestions and remainingQuestions must not overlap")
    return errors, warnings


def validate_record(record: dict[str, Any], *, strict: bool = False) -> dict[str, Any]:
    version = record.get("schemaVersion")
    report: dict[str, Any] = {
        "schemaVersion": version,
        "recordType": record.get("recordType"),
    }
    if version == "1.0":
        errors = validate_legacy_10(record)
        report["errors"] = errors
        report["valid"] = not errors
        report["legacy"] = True
        report["message"] = "Schema 1.0 input is readable; run normalize to upgrade to 1.2"
        report["warnings"] = []
        return report
    errors, warnings = validate_current(record)
    report["errors"] = errors
    report["warnings"] = warnings
    report["valid"] = not errors and not (strict and warnings)
    if strict and warnings and not errors:
        report["errors"] = [*errors, "strict mode: warnings are fatal"]
    return report


def merge_items(
    a: Any,
    b: Any,
    path: str,
    conflicts: list[dict[str, Any]],
    newer: str | None = None,
) -> Any:
    """Deterministic two-way merge with an audit trail for scalar conflicts.

    The newer ``updatedAt`` side supplies the active value, while the conflict
    record retains both inputs. Equal or missing timestamps keep the first
    value and are also recorded. The timestamp field itself is version
    metadata rather than a user-data conflict.
    """
    if a == b:
        return a
    if isinstance(a, dict) and isinstance(b, dict):
        merged = dict(a)
        for key in b:
            if key not in a:
                merged[key] = b[key]
            else:
                merged[key] = merge_items(
                    a[key], b[key], f"{path}/{_pointer_escape(key)}", conflicts, newer
                )
        return merged
    if isinstance(a, list) and isinstance(b, list):
        return merge_lists(a, b, path, conflicts, newer)
    if path.endswith("/updatedAt"):
        return b if newer == "b" else a
    conflicts.append({
        "path": path,
        "a": a,
        "b": b,
        "resolution": "kept-newer" if newer in {"a", "b"} else "kept-first",
    })
    return b if newer == "b" else a


def _item_key(
    item: Any, *, metric: bool = False, accuracy: bool = False
) -> tuple[str, ...] | None:
    if not isinstance(item, dict):
        return None
    if accuracy and "subject" in item:
        return ("accuracy", str(item["subject"]))
    if item.get("itemId"):
        return ("itemId", str(item["itemId"]))
    name = item.get("name")
    if metric and name:
        return ("metric", str(item.get("subject")), str(name), str(item.get("unit")))
    subject = item.get("subject")
    topic = item.get("topic")
    if is_non_empty_string(topic):
        return ("topic", str(subject), str(topic))
    return None


def merge_lists(
    a: list[Any],
    b: list[Any],
    path: str,
    conflicts: list[dict[str, Any]],
    newer: str | None = None,
) -> list[Any]:
    """Merge keyed list items using the enclosing record's timestamp decision."""
    metric_items = path.endswith("/metrics")
    accuracy_items = path.endswith("/accuracy")
    if any(_item_key(entry, metric=metric_items, accuracy=accuracy_items) is not None for entry in a) and any(
        _item_key(entry, metric=metric_items, accuracy=accuracy_items) is not None for entry in b
    ):
        merged = list(a)
        index_of: dict[tuple[str, ...], int] = {}
        for index, entry in enumerate(merged):
            key = _item_key(entry, metric=metric_items, accuracy=accuracy_items)
            if key is not None and key not in index_of:
                index_of[key] = index
        for entry in b:
            key = _item_key(entry, metric=metric_items, accuracy=accuracy_items)
            if key is not None and key in index_of:
                target = merged[index_of[key]]
                merged[index_of[key]] = merge_items(
                    target, entry, f"{path}/{index_of[key]}", conflicts, newer
                )
            elif entry not in merged:
                merged.append(entry)
        return merged
    merged = list(a)
    for entry in b:
        if entry not in merged:
            merged.append(entry)
    return merged


def natural_key(record: dict[str, Any]) -> tuple:
    record_type = record.get("recordType")
    if record_type == "ProgressSnapshot":
        period = record.get("period") or {}
        return (record_type, period.get("start"), period.get("end"))
    if record_type == "ReviewQueue":
        return (record_type, record.get("generatedAt"))
    if record_type == "SessionCheckpoint":
        return (record_type, record.get("checkpointId") or record.get("currentTask"))
    return (record_type,)


def records_match(a: dict[str, Any], b: dict[str, Any]) -> bool:
    if a.get("recordType") != b.get("recordType"):
        return False
    if a.get("recordType") == "SessionCheckpoint":
        checkpoint_a, checkpoint_b = a.get("checkpointId"), b.get("checkpointId")
        if checkpoint_a and checkpoint_b:
            return checkpoint_a == checkpoint_b
        return natural_key(a) == natural_key(b)
    id_a, id_b = a.get("recordId"), b.get("recordId")
    if id_a and id_b:
        return id_a == id_b
    return natural_key(a) == natural_key(b)


def valid_checkpoint_revision(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value >= 1


def merge_records(a: dict[str, Any], b: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    if not records_match(a, b):
        # Distinct records: keep both rather than dropping either side.
        return {}, []
    conflicts: list[dict[str, Any]] = []
    updated_a, updated_b = a.get("updatedAt"), b.get("updatedAt")
    newer = None
    revision_a, revision_b = a.get("checkpointRevision"), b.get("checkpointRevision")
    if a.get("recordType") == "SessionCheckpoint":
        for record in (a, b):
            if "checkpointRevision" in record and not valid_checkpoint_revision(record["checkpointRevision"]):
                raise RecordError("checkpointRevision must be a positive integer")
    has_revisions = all(
        valid_checkpoint_revision(value)
        for value in (revision_a, revision_b)
    )
    if a.get("recordType") == "SessionCheckpoint" and has_revisions:
        if revision_a != revision_b:
            newer = "b" if revision_b > revision_a else "a"
    elif is_plain_date(updated_a) and is_plain_date(updated_b) and updated_a != updated_b:
        newer = "b" if updated_b > updated_a else "a"
    if a.get("recordType") == "SessionCheckpoint":
        # Resume state belongs to a complete snapshot. Do not mix old optional
        # fields or removed queue items into the selected checkpoint.
        merged = merge_items(
            {key: value for key, value in a.items() if key not in CHECKPOINT_STATE_FIELDS},
            {key: value for key, value in b.items() if key not in CHECKPOINT_STATE_FIELDS},
            "", conflicts, newer,
        )
        state = b if newer == "b" else a
        missing = object()
        for key in CHECKPOINT_STATE_FIELDS:
            if key in state:
                merged[key] = deepcopy(state[key])
            if key == "updatedAt" or a.get(key, missing) == b.get(key, missing):
                continue
            conflict = {
                "path": f"/{key}", "a": a.get(key), "b": b.get(key),
                "resolution": "kept-newer" if newer is not None else "kept-first",
            }
            if key not in a or key not in b:
                conflict.update({"aPresent": key in a, "bPresent": key in b})
            conflicts.append(conflict)
        return merged, conflicts
    return merge_items(a, b, "", conflicts, newer), conflicts


def merge_documents(a: Any, b: Any) -> dict[str, Any]:
    records_a = as_record_list(a)
    records_b = as_record_list(b)
    merged_records: list[dict[str, Any]] = []
    conflicts: list[dict[str, Any]] = []
    for document in (a, b):
        if isinstance(document, dict) and "records" in document and "mergeConflicts" in document:
            previous = document["mergeConflicts"]
            if not isinstance(previous, list) or any(not isinstance(entry, dict) for entry in previous):
                raise RecordError("mergeConflicts must be an array of objects")
            conflicts.extend(deepcopy(previous))
    pending_b = list(records_b)
    for record_a in records_a:
        merged_record = record_a
        remaining: list[dict[str, Any]] = []
        for record_b in pending_b:
            joined, record_conflicts = merge_records(merged_record, record_b)
            if joined:
                merged_record = joined
                conflicts.extend(record_conflicts)
            else:
                remaining.append(record_b)
        pending_b = remaining
        merged_records.append(merged_record)
    merged_records.extend(pending_b)
    unique_conflicts: list[dict[str, Any]] = []
    fingerprints: set[str] = set()
    for conflict in conflicts:
        fingerprint = json.dumps(conflict, ensure_ascii=False, sort_keys=True, allow_nan=False)
        if fingerprint not in fingerprints:
            fingerprints.add(fingerprint)
            unique_conflicts.append(conflict)
    return {"records": merged_records, "mergeConflicts": unique_conflicts}


def resolve_due(items: list[dict[str, Any]], base: date) -> dict[str, Any]:
    due: list[dict[str, Any]] = []
    not_due: list[dict[str, Any]] = []
    needs_base: list[dict[str, Any]] = []
    for index, item in enumerate(items):
        if not isinstance(item, dict):
            raise RecordError(f"items[{index}] must be an object")
        offset_value = item.get("retestOffsetDays")
        if offset_value is not None and (
            isinstance(offset_value, bool)
            or not isinstance(offset_value, int)
            or offset_value < 0
        ):
            raise RecordError(f"items[{index}].retestOffsetDays must be a non-negative integer or null")
        label = item.get("itemId") or f"items[{index}]"
        summary = {
            "item": label,
            "subject": item.get("subject"),
            "topic": item.get("topic"),
            "status": item.get("status"),
        }
        next_date = item.get("nextRetestDate")
        offset, anchor = item.get("retestOffsetDays"), item.get("retestAnchorDate")
        if next_date is not None and not is_plain_date(next_date):
            raise RecordError(f"items[{index}].nextRetestDate must be a valid date or null")
        if anchor is not None and not is_plain_date(anchor):
            raise RecordError(f"items[{index}].retestAnchorDate must be a valid date or null")
        if is_plain_date(next_date) and offset is not None:
            raise RecordError(
                f"items[{index}] must not carry both nextRetestDate and retestOffsetDays"
            )
        if is_plain_date(next_date):
            (due if date.fromisoformat(next_date) <= base else not_due).append(summary)
        elif isinstance(offset, int) and is_plain_date(anchor):
            resolved = date.fromisoformat(anchor) + timedelta(days=offset)
            entry = {**summary, "resolvedDate": resolved.isoformat()}
            (due if resolved <= base else not_due).append(entry)
        elif isinstance(offset, int):
            needs_base.append({**summary, "retestOffsetDays": offset})
        else:
            needs_base.append({**summary, "reason": "no nextRetestDate or retestOffsetDays"})
    return {"date": base.isoformat(), "due": due, "notDue": not_due, "needsBaseDate": needs_base}


def run_normalize(document: Any) -> dict[str, Any]:
    results = []
    for record in as_record_list(document):
        converted, warnings = normalize_to_12(record)
        results.append({"record": converted, "migrationWarnings": warnings})
    if len(results) == 1:
        return {"record": results[0]["record"], "migrationWarnings": results[0]["migrationWarnings"]}
    return {
        "records": [entry["record"] for entry in results],
        "migrationWarnings": [warning for entry in results for warning in entry["migrationWarnings"]],
    }


def build_checkpoint(payload: dict[str, Any], base_date: str | None) -> dict[str, Any]:
    checkpoint = {
        "schemaVersion": SCHEMA_VERSION_CURRENT,
        "recordType": "SessionCheckpoint",
        "updatedAt": base_date,
        "currentTask": payload.get("currentTask"),
        "position": payload.get("position"),
        "dueItems": payload["dueItems"] if "dueItems" in payload else [],
        "pendingRetests": payload["pendingRetests"] if "pendingRetests" in payload else [],
        "notes": payload.get("notes"),
        "teachingMode": payload.get("teachingMode"),
        "answerState": payload.get("answerState"),
        "hintLevel": payload.get("hintLevel"),
        "currentQuestion": payload.get("currentQuestion"),
        "completedQuestions": payload["completedQuestions"] if "completedQuestions" in payload else [],
        "remainingQuestions": payload["remainingQuestions"] if "remainingQuestions" in payload else [],
        "materialVersion": payload.get("materialVersion"),
    }
    if "checkpointId" in payload:
        checkpoint["checkpointId"] = payload["checkpointId"]
        checkpoint["checkpointRevision"] = payload.get("checkpointRevision", 1)
    else:
        checkpoint["checkpointId"] = stable_id("kc", {**checkpoint, "updatedAt": None})
        checkpoint["checkpointRevision"] = 1
    errors, _ = validate_current(checkpoint)
    if errors:
        raise RecordError("checkpoint is invalid: " + "; ".join(errors))
    return checkpoint


def update_checkpoint(
    checkpoint: dict[str, Any], changes: dict[str, Any], base_date: str | None,
) -> dict[str, Any]:
    """Advance one existing snapshot without changing its stable identity."""
    if not isinstance(checkpoint, dict) or checkpoint.get("recordType") != "SessionCheckpoint":
        raise RecordError("checkpoint update requires recordType SessionCheckpoint")
    errors, _ = validate_current(checkpoint)
    if errors:
        raise RecordError("checkpoint is invalid: " + "; ".join(errors))
    if not checkpoint.get("checkpointId"):
        raise RecordError("checkpoint update requires checkpointId; normalize the record first")
    if not isinstance(changes, dict):
        raise RecordError("checkpoint changes must be a JSON object")
    if any(key not in CHECKPOINT_EDIT_FIELDS for key in changes):
        raise RecordError("checkpoint changes may contain only mutable resume fields")
    if base_date is not None and not is_plain_date(base_date):
        raise RecordError("checkpoint update date must be a YYYY-MM-DD date or null")
    updated = deepcopy(checkpoint)
    updated.update(deepcopy(changes))
    errors, _ = validate_current(updated)
    if errors:
        raise RecordError("updated checkpoint is invalid: " + "; ".join(errors))
    missing = object()
    if all(checkpoint.get(key, missing) == value for key, value in changes.items()):
        return deepcopy(checkpoint)
    updated["checkpointRevision"] = checkpoint.get("checkpointRevision", 0) + 1
    updated["updatedAt"] = base_date
    errors, _ = validate_current(updated)
    if errors:
        raise RecordError("updated checkpoint is invalid: " + "; ".join(errors))
    return updated


def read_checkpoint(
    checkpoint: dict[str, Any],
    base: date | None,
    queue: dict[str, Any] | list[dict[str, Any]] | None,
) -> dict[str, Any]:
    if checkpoint.get("recordType") != "SessionCheckpoint":
        raise RecordError("checkpoint read requires recordType SessionCheckpoint")
    errors, warnings = validate_current(checkpoint)
    if errors:
        raise RecordError("checkpoint is invalid: " + "; ".join(errors))
    plan: dict[str, Any] = {
        "resume": {
            "checkpointRevision": checkpoint.get("checkpointRevision"),
            "currentTask": checkpoint.get("currentTask"),
            "position": checkpoint.get("position"),
            "notes": checkpoint.get("notes"),
            "teachingMode": checkpoint.get("teachingMode"),
            "answerState": checkpoint.get("answerState"),
            "hintLevel": checkpoint.get("hintLevel"),
            "currentQuestion": checkpoint.get("currentQuestion"),
            "completedQuestions": checkpoint.get("completedQuestions", []),
            "remainingQuestions": checkpoint.get("remainingQuestions", []),
            "materialVersion": checkpoint.get("materialVersion"),
        },
        "dueItems": checkpoint.get("dueItems", []),
        "pendingRetests": checkpoint.get("pendingRetests", []),
    }
    if base is not None and queue is not None:
        items: list[dict[str, Any]] = []
        for record in as_record_list(queue):
            if record.get("recordType") == "ReviewQueue":
                queue_items = record.get("items", [])
                if not isinstance(queue_items, list):
                    raise RecordError("items must be an array")
                items.extend(queue_items)
        plan["dueReview"] = resolve_due(items, base)
    if warnings:
        plan["warnings"] = warnings
    return plan


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    validate_parser = subparsers.add_parser("validate", help="validate a record document")
    validate_parser.add_argument("input", nargs="?", default="-")
    validate_parser.add_argument("--strict", action="store_true", help="treat warnings as fatal")

    normalize_parser = subparsers.add_parser("normalize", help="normalize 1.0/1.1 records to 1.2")
    normalize_parser.add_argument("input", nargs="?", default="-")

    merge_parser = subparsers.add_parser("merge", help="merge two record documents")
    merge_parser.add_argument("first")
    merge_parser.add_argument("second")

    due_parser = subparsers.add_parser("due", help="list due review items for a base date")
    due_parser.add_argument("input", nargs="?", default="-")
    due_parser.add_argument("--date", required=True, dest="base_date", help="explicit base date YYYY-MM-DD")

    checkpoint_parser = subparsers.add_parser("checkpoint", help="create, update, or read a SessionCheckpoint")
    checkpoint_sub = checkpoint_parser.add_subparsers(dest="checkpoint_command", required=True)
    create_parser = checkpoint_sub.add_parser("create")
    create_parser.add_argument("input", nargs="?", default="-")
    create_parser.add_argument("--date", default=None, dest="base_date")
    update_parser = checkpoint_sub.add_parser("update")
    update_parser.add_argument("input", nargs="?", default="-")
    update_parser.add_argument("--changes", required=True, help="JSON object containing changed resume fields")
    update_parser.add_argument("--date", default=None, dest="base_date")
    read_parser = checkpoint_sub.add_parser("read")
    read_parser.add_argument("input", nargs="?", default="-")
    read_parser.add_argument("--date", default=None, dest="base_date")
    read_parser.add_argument("--queue", default=None, help="optional ReviewQueue document for due computation")
    return parser


def _configure_windows_stdio() -> None:
    """Use UTF-8 for PowerShell 7 native-command pipelines on Windows."""
    if sys.platform != "win32":
        return
    for stream in (sys.stdin, sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="strict")


def main(argv: list[str] | None = None) -> int:
    _configure_windows_stdio()
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        base = date.fromisoformat(args.base_date) if getattr(args, "base_date", None) else None
        if args.command == "validate":
            report = [validate_record(record, strict=args.strict) for record in as_record_list(load_document(args.input))]
            invalid = [entry for entry in report if not entry["valid"]]
            emit({"valid": not invalid, "results": report} if len(report) > 1 else report[0])
            return 1 if invalid else 0
        if args.command == "normalize":
            emit(run_normalize(load_document(args.input)))
            return 0
        if args.command == "merge":
            first_is_stdin, second_is_stdin = args.first == "-", args.second == "-"
            if first_is_stdin and second_is_stdin:
                raise RecordError("merge accepts at most one '-' stdin input")
            first = load_document(args.first)
            second = load_document(args.second)
            emit(merge_documents(first, second))
            return 0
        if args.command == "due":
            queue_items: list[dict[str, Any]] = []
            for record in as_record_list(load_document(args.input)):
                if record.get("recordType") == "ReviewQueue":
                    items = record.get("items", [])
                    if not isinstance(items, list):
                        raise RecordError("items must be an array")
                    queue_items.extend(items)
            emit(resolve_due(queue_items, base))  # type: ignore[arg-type]
            return 0
        if args.command == "checkpoint":
            document = load_document(args.input)
            record = document if isinstance(document, dict) else None
            if record is None:
                raise RecordError("checkpoint input must be a JSON object")
            if args.checkpoint_command == "create":
                emit(build_checkpoint(record, args.base_date))
                return 0
            if args.checkpoint_command == "update":
                if args.input == "-" and args.changes == "-":
                    raise RecordError("checkpoint update accepts at most one '-' stdin input")
                emit(update_checkpoint(record, load_document(args.changes), args.base_date))
                return 0
            queue = load_document(args.queue) if args.queue else None
            emit(read_checkpoint(record, base, queue))
            return 0
        parser.error(f"unknown command: {args.command}")  # pragma: no cover - argparse guards
    except RecordError as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1
    except (AttributeError, KeyError, OverflowError, TypeError, ValueError) as exc:
        # Malformed user-supplied JSON must produce the promised CLI error, never a traceback.
        print(
            json.dumps({"error": f"invalid record structure ({exc.__class__.__name__})"}, ensure_ascii=False),
            file=sys.stderr,
        )
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
