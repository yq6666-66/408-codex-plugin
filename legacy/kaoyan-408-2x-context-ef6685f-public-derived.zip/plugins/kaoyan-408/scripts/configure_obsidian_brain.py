#!/usr/bin/env python3
"""Configure and validate the optional local Obsidian brain."""

from __future__ import annotations

import argparse
import json
import os
import tempfile
from datetime import datetime
from pathlib import Path, PurePosixPath
from typing import Any


SCHEMA_VERSION = "1.1"
LEGACY_SCHEMA_VERSION = "1.0"
DEFAULT_PROJECT_ROOT = "20-项目/408考研"
DEFAULT_KNOWLEDGE_ROOT = "30-知识/408考研"
DEFAULT_PAST_PAPER_ROOT = "40-真题/408考研"
DEFAULT_WRITE_MODE = "auto-structured"
DEFAULT_RETRIEVAL_SCOPE = "project-first"
EXPECTED_KEYS = {
    "schemaVersion",
    "enabled",
    "vaultPath",
    "projectRoot",
    "knowledgeRoot",
    "pastPaperRoot",
    "writeMode",
    "retrievalScope",
}


class BrainConfigError(RuntimeError):
    """Raised when the local brain cannot be configured safely."""


def default_config_path() -> Path:
    return Path.home() / ".codex" / "kaoyan-408" / "obsidian-brain.json"


def default_legacy_config_path() -> Path:
    return Path.home() / ".codex" / "kaoyan-22408" / "obsidian-brain.json"


def local_date() -> str:
    return datetime.now().astimezone().date().isoformat()


def _validate_project_root(value: str) -> PurePosixPath:
    if "\\" in value:
        raise BrainConfigError("projectRoot must use forward slashes")
    project = PurePosixPath(value)
    if project.is_absolute() or not project.parts:
        raise BrainConfigError("projectRoot must be a non-empty relative path")
    if any(part in {"", ".", ".."} for part in project.parts):
        raise BrainConfigError("projectRoot contains an unsafe path segment")
    return project


def _require_real_directory(path: Path, label: str) -> Path:
    try:
        resolved = path.expanduser().resolve(strict=True)
    except OSError as exc:
        raise BrainConfigError(f"{label} does not exist: {path}") from exc
    if not resolved.is_dir():
        raise BrainConfigError(f"{label} is not a directory: {resolved}")
    if path.expanduser().is_symlink():
        raise BrainConfigError(f"{label} must not be a symbolic link: {path}")
    return resolved


def _assert_no_symlink_chain(vault: Path, target: Path) -> None:
    try:
        relative = target.relative_to(vault)
    except ValueError as exc:
        raise BrainConfigError(f"target escapes Vault: {target}") from exc
    cursor = vault
    for part in relative.parts:
        cursor = cursor / part
        if cursor.is_symlink():
            raise BrainConfigError(f"Vault target traverses a symbolic link: {cursor}")


def validate_config(data: Any, *, require_paths: bool = True) -> dict[str, Any]:
    if not isinstance(data, dict) or set(data) != EXPECTED_KEYS:
        raise BrainConfigError(f"config must contain exactly: {sorted(EXPECTED_KEYS)}")
    if data["schemaVersion"] != SCHEMA_VERSION:
        raise BrainConfigError(f"unsupported schemaVersion: {data['schemaVersion']!r}")
    if not isinstance(data["enabled"], bool):
        raise BrainConfigError("enabled must be boolean")
    if data["writeMode"] != DEFAULT_WRITE_MODE:
        raise BrainConfigError(f"writeMode must be {DEFAULT_WRITE_MODE!r}")
    if data["retrievalScope"] != DEFAULT_RETRIEVAL_SCOPE:
        raise BrainConfigError(f"retrievalScope must be {DEFAULT_RETRIEVAL_SCOPE!r}")
    if not isinstance(data["vaultPath"], str) or not data["vaultPath"]:
        raise BrainConfigError("vaultPath must be a non-empty string")
    if not Path(data["vaultPath"]).is_absolute():
        raise BrainConfigError("vaultPath must be an absolute path")
    roots: dict[str, PurePosixPath] = {}
    for key in ("projectRoot", "knowledgeRoot", "pastPaperRoot"):
        if not isinstance(data[key], str):
            raise BrainConfigError(f"{key} must be a string")
        roots[key] = _validate_project_root(data[key])
    if require_paths:
        vault = _require_real_directory(Path(data["vaultPath"]), "Vault")
        for required in ("AGENTS.md", "00-系统/知识库索引.md"):
            candidate = vault / Path(*PurePosixPath(required).parts)
            _assert_no_symlink_chain(vault, candidate)
            if not candidate.is_file():
                raise BrainConfigError(f"Vault is missing required file: {required}")
        if data["enabled"]:
            for key, root in roots.items():
                candidate = vault / Path(*root.parts)
                _assert_no_symlink_chain(vault, candidate)
                if not candidate.is_dir():
                    raise BrainConfigError(f"enabled {key} must exist as a Vault directory")
    return data


def load_legacy_config(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise BrainConfigError(f"cannot read legacy config: {path}: {exc}") from exc
    expected = {"schemaVersion", "enabled", "vaultPath", "projectRoot", "writeMode", "retrievalScope"}
    if not isinstance(data, dict) or set(data) != expected or data.get("schemaVersion") != LEGACY_SCHEMA_VERSION:
        raise BrainConfigError("legacy config must be a valid Schema 1.0 object")
    if not isinstance(data.get("enabled"), bool):
        raise BrainConfigError("legacy enabled must be boolean")
    if not isinstance(data.get("vaultPath"), str) or not data["vaultPath"]:
        raise BrainConfigError("legacy vaultPath must be a non-empty string")
    if not Path(data["vaultPath"]).is_absolute():
        raise BrainConfigError("legacy vaultPath must be an absolute path")
    if not isinstance(data.get("projectRoot"), str):
        raise BrainConfigError("legacy projectRoot must be a string")
    if data.get("writeMode") != DEFAULT_WRITE_MODE or data.get("retrievalScope") != DEFAULT_RETRIEVAL_SCOPE:
        raise BrainConfigError("legacy config has unsupported modes")
    vault = _require_real_directory(Path(data.get("vaultPath", "")), "Vault")
    project = _validate_project_root(data.get("projectRoot", ""))
    _assert_no_symlink_chain(vault, vault / Path(*project.parts))
    return data


def load_config(path: Path, *, require_paths: bool = True) -> dict[str, Any]:
    try:
        payload = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise BrainConfigError(f"cannot read config: {path}") from exc
    try:
        data = json.loads(payload)
    except json.JSONDecodeError as exc:
        raise BrainConfigError(f"invalid config JSON: {exc}") from exc
    return validate_config(data, require_paths=require_paths)


def _atomic_write(path: Path, payload: str) -> None:
    temporary: Path | None = None
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temporary_name = tempfile.mkstemp(
            dir=path.parent,
            prefix=f".{path.name}.",
            suffix=".tmp",
        )
        temporary = Path(temporary_name)
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
        except Exception:
            try:
                os.close(descriptor)
            except OSError:
                pass
            raise
    except OSError as exc:
        raise BrainConfigError(f"cannot write {path}: {exc}") from exc
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def _write_if_missing(path: Path, payload: str, actions: list[str], *, dry_run: bool) -> None:
    if path.is_symlink():
        raise BrainConfigError(f"refusing to follow symbolic link scaffold file: {path}")
    if path.exists():
        if not path.is_file():
            raise BrainConfigError(f"expected a regular scaffold file: {path}")
        actions.append(f"keep {path}")
        return
    actions.append(f"create {path}")
    if not dry_run:
        _atomic_write(path, payload)


def _append_once(path: Path, marker: str, addition: str, actions: list[str], *, dry_run: bool) -> None:
    if path.is_symlink():
        raise BrainConfigError(f"refusing to follow symbolic link scaffold file: {path}")
    current = path.read_text(encoding="utf-8")
    if marker in current:
        actions.append(f"keep {path}")
        return
    actions.append(f"update {path}")
    if not dry_run:
        _atomic_write(path, current.rstrip() + "\n\n" + addition.rstrip() + "\n")


def scaffold_vault(
    vault: Path,
    project_root: PurePosixPath,
    knowledge_root: PurePosixPath,
    past_paper_root: PurePosixPath,
    *,
    dry_run: bool,
) -> list[str]:
    for required in ("AGENTS.md", "00-系统/知识库索引.md"):
        _assert_no_symlink_chain(vault, vault / Path(*PurePosixPath(required).parts))
    project = vault / Path(*project_root.parts)
    knowledge = vault / Path(*knowledge_root.parts)
    past_papers = vault / Path(*past_paper_root.parts)
    _assert_no_symlink_chain(vault, project)
    _assert_no_symlink_chain(vault, knowledge)
    _assert_no_symlink_chain(vault, past_papers)
    actions: list[str] = []
    if not dry_run:
        project.mkdir(parents=True, exist_ok=True)
        knowledge.mkdir(parents=True, exist_ok=True)
        past_papers.mkdir(parents=True, exist_ok=True)
    today = local_date()
    common = f"""---
type: project
status: active
created: {today}
updated: {today}
tags:
  - 考研
  - 408
---
"""
    files = {
        "主页.md": common
        + """
# 408考研

kaoyan-408-brain

- [[学习档案]]
- [[当前进度]]
- [[错题队列]]
- [[学习检查点]]
- [[记忆索引]]
- [[知识库索引]]
- [[真题索引]]
""",
        "学习档案.md": common
        + """
# 学习档案

```json
{
  "schemaVersion": "1.2",
  "recordType": "StudyProfile",
  "targetExam": null,
  "targetDate": null,
  "weeklyHours": null,
  "currentPhase": null,
  "constraints": []
}
```
""",
        "当前进度.md": common
        + """
# 当前进度

尚无用户确认的进度快照。
""",
        "错题队列.md": common
        + """
# 错题队列

```json
{
  "schemaVersion": "1.2",
  "recordType": "ReviewQueue",
  "generatedAt": null,
  "items": []
}
```
""",
        "学习检查点.md": common
        + """
# 学习检查点

```json
{
  "schemaVersion": "1.2",
  "recordType": "SessionCheckpoint",
  "updatedAt": null,
  "currentTask": null,
  "position": null,
  "dueItems": [],
  "pendingRetests": []
}
```
""",
        "记忆索引.md": common
        + """
# 记忆索引

## 当前记录

- [[学习档案]]
- [[当前进度]]
- [[错题队列]]
- [[学习检查点]]

## 主题

暂无。
""",
    }
    for name, payload in files.items():
        _write_if_missing(project / name, payload.lstrip(), actions, dry_run=dry_run)
    home = project / "主页.md"
    if home.exists():
        _append_once(
            home,
            "kaoyan-408-brain",
            "## 408考研插件\n\n- kaoyan-408-brain\n- 真题入口：[[真题索引]]",
            actions,
            dry_run=dry_run,
        )
    _write_if_missing(
        past_papers / "真题索引.md",
        (common + "\n# 真题索引\n\n范围：2010 年起（不设固定结束年份）数学一、数学二、英语一、英语二、408、政治。\n").lstrip(),
        actions,
        dry_run=dry_run,
    )
    for subject in ("数学一", "数学二", "英语一", "英语二", "408", "政治"):
        subject_dir = past_papers / subject
        _assert_no_symlink_chain(vault, subject_dir)
        if not dry_run:
            subject_dir.mkdir(parents=True, exist_ok=True)
    index = vault / "00-系统" / "知识库索引.md"
    growth = vault / "00-系统" / "成长日志.md"
    _append_once(
        index,
        "kaoyan-408-brain",
        "## 408考研插件\n\n- kaoyan-408-brain\n- [[主页]]\n- [[记忆索引]]\n- [[真题索引]]",
        actions,
        dry_run=dry_run,
    )
    if growth.exists():
        _append_once(
            growth,
            f"{today} | 408考研插件 | 初始化 Obsidian 学习大脑",
            f"- {today} | 408考研插件 | 初始化 Obsidian 学习大脑",
            actions,
            dry_run=dry_run,
        )
    return actions


def configure(args: argparse.Namespace) -> int:
    vault = _require_real_directory(args.vault, "Vault")
    for required in ("AGENTS.md", "00-系统/知识库索引.md"):
        if not (vault / Path(*PurePosixPath(required).parts)).is_file():
            raise BrainConfigError(f"Vault is missing required file: {required}")
    project_root = _validate_project_root(args.project_root)
    knowledge_root = _validate_project_root(args.knowledge_root)
    past_paper_root = _validate_project_root(args.past_paper_root)
    config = {
        "schemaVersion": SCHEMA_VERSION,
        "enabled": True,
        "vaultPath": str(vault),
        "projectRoot": project_root.as_posix(),
        "knowledgeRoot": knowledge_root.as_posix(),
        "pastPaperRoot": past_paper_root.as_posix(),
        "writeMode": DEFAULT_WRITE_MODE,
        "retrievalScope": DEFAULT_RETRIEVAL_SCOPE,
    }
    validate_config(config, require_paths=False)
    actions = scaffold_vault(vault, project_root, knowledge_root, past_paper_root, dry_run=args.dry_run)
    if not args.dry_run:
        validate_config(config, require_paths=True)
    config_path = args.config.expanduser()
    actions.append(f"write {config_path}")
    if not args.dry_run:
        _atomic_write(config_path, json.dumps(config, ensure_ascii=False, indent=2) + "\n")
    prefix = "[DRY-RUN]" if args.dry_run else "[OK]"
    for action in actions:
        print(f"{prefix} {action}")
    return 0


def set_enabled(args: argparse.Namespace, enabled: bool) -> int:
    config = load_config(args.config.expanduser(), require_paths=enabled)
    config["enabled"] = enabled
    validate_config(config, require_paths=enabled)
    if args.dry_run:
        print(f"[DRY-RUN] set enabled={str(enabled).lower()} in {args.config}")
    else:
        _atomic_write(
            args.config.expanduser(),
            json.dumps(config, ensure_ascii=False, indent=2) + "\n",
        )
        print(f"[OK] enabled={str(enabled).lower()}")
    return 0


def migrate(args: argparse.Namespace) -> int:
    legacy_path = args.legacy_config.expanduser()
    legacy = load_legacy_config(legacy_path)
    target = args.config.expanduser()
    if target.exists() and not args.force:
        raise BrainConfigError(f"new config already exists; refusing to overwrite: {target}")
    vault = _require_real_directory(Path(legacy["vaultPath"]), "Vault")
    project_root = _validate_project_root(legacy["projectRoot"])
    legacy_knowledge = PurePosixPath("30-知识/考研 22408")
    knowledge_root = (
        legacy_knowledge
        if (vault / Path(*legacy_knowledge.parts)).is_dir()
        else PurePosixPath(DEFAULT_KNOWLEDGE_ROOT)
    )
    past_paper_root = PurePosixPath(DEFAULT_PAST_PAPER_ROOT)
    config = {
        "schemaVersion": SCHEMA_VERSION,
        "enabled": legacy["enabled"],
        "vaultPath": str(vault),
        "projectRoot": project_root.as_posix(),
        "knowledgeRoot": knowledge_root.as_posix(),
        "pastPaperRoot": past_paper_root.as_posix(),
        "writeMode": DEFAULT_WRITE_MODE,
        "retrievalScope": DEFAULT_RETRIEVAL_SCOPE,
    }
    validate_config(config, require_paths=False)
    actions = scaffold_vault(vault, project_root, knowledge_root, past_paper_root, dry_run=args.dry_run)
    if not args.dry_run and config["enabled"]:
        validate_config(config, require_paths=True)
    actions.append(f"write {target}")
    if not args.dry_run:
        _atomic_write(target, json.dumps(config, ensure_ascii=False, indent=2) + "\n")
    prefix = "[DRY-RUN]" if args.dry_run else "[OK]"
    for action in actions:
        print(f"{prefix} {action}")
    print(f"{prefix} legacy config preserved: {legacy_path}")
    return 0


def check(args: argparse.Namespace) -> int:
    config = load_config(args.config.expanduser(), require_paths=False)
    if config["enabled"]:
        validate_config(config, require_paths=True)
    print(f"[OK] config: {args.config.expanduser()}")
    print(f"[OK] enabled: {str(config['enabled']).lower()}")
    print(f"[OK] Vault: {config['vaultPath']}")
    print(f"[OK] projectRoot: {config['projectRoot']}")
    print(f"[OK] knowledgeRoot: {config['knowledgeRoot']}")
    print(f"[OK] pastPaperRoot: {config['pastPaperRoot']}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=default_config_path())
    subparsers = parser.add_subparsers(dest="command", required=True)

    configure_parser = subparsers.add_parser("configure")
    configure_parser.add_argument("--vault", type=Path, required=True)
    configure_parser.add_argument("--project-root", default=DEFAULT_PROJECT_ROOT)
    configure_parser.add_argument("--knowledge-root", default=DEFAULT_KNOWLEDGE_ROOT)
    configure_parser.add_argument("--past-paper-root", default=DEFAULT_PAST_PAPER_ROOT)
    configure_parser.add_argument("--dry-run", action="store_true")
    configure_parser.set_defaults(handler=configure)

    check_parser = subparsers.add_parser("check")
    check_parser.set_defaults(handler=check)

    migrate_parser = subparsers.add_parser("migrate")
    migrate_parser.add_argument("--legacy-config", type=Path, default=default_legacy_config_path())
    migrate_parser.add_argument("--force", action="store_true")
    migrate_parser.add_argument("--dry-run", action="store_true")
    migrate_parser.set_defaults(handler=migrate)

    for name, enabled in (("enable", True), ("disable", False)):
        toggle = subparsers.add_parser(name)
        toggle.add_argument("--dry-run", action="store_true")
        toggle.set_defaults(handler=lambda args, value=enabled: set_enabled(args, value))
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.handler(args)
    except BrainConfigError as exc:
        print(f"[FAIL] {exc}")
        return 1
    except (OSError, UnicodeError) as exc:
        print(f"[FAIL] filesystem operation failed ({exc.__class__.__name__})")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
