#!/usr/bin/env python3
"""Validate the public Skills-only repository and its release payload."""

from __future__ import annotations

import argparse
import io
import json
import re
import subprocess
import sys
from pathlib import Path, PurePosixPath
from typing import Any

import yaml
from jsonschema import Draft202012Validator, FormatChecker
from jsonschema.exceptions import SchemaError, ValidationError as JsonSchemaValidationError
from yaml.constructor import ConstructorError
from yaml.nodes import MappingNode

from release_payload import (
    ALLOWED_PLUGIN_ROOTS,
    CODEBUDDY_MANIFEST_RELATIVE,
    CLAUDE_MANIFEST_RELATIVE,
    ALLOWED_RELEASE_FILES,
    EXPECTED_REFERENCES,
    EXPECTED_SKILLS,
    PLACEHOLDER,
    PLUGIN_RELATIVE_PATH,
    SEMVER_PATTERN,
    ValidationError,
    ZCODE_MANIFEST_RELATIVE,
    check_accuracy_semantics,
    check_mastery_evidence_semantics,
    expected_release_files,
    read_utf8_text,
    require,
)

SEMVER = re.compile(SEMVER_PATTERN)
FORBIDDEN_PATH_PARTS = {"app", "android", "corpus", "raw", "index", "user"}
HISTORY_FORBIDDEN_PATH_PARTS = {"app", "android", "corpus", "raw"}
CLAUDE_MANIFEST_PART = PurePosixPath(CLAUDE_MANIFEST_RELATIVE)
CLAUDE_MIRRORED_MANIFEST_FIELDS = (
    "version", "description", "author", "homepage", "repository", "license", "keywords", "skills",
)
CLAUDE_FORBIDDEN_MANIFEST_KEYS = (
    "interface", "apps", "mcpServers", "lspServers", "hooks", "commands", "agents",
    "userConfig", "outputStyles", "experimental", "channels", "dependencies",
    "workflows", "monitors", "settings",
)
# The shared marketplace must remain valid in both native hosts. Native Claude
# validation rejects unknown keys under --strict, including ZCode i18n extensions.
SHARED_MARKETPLACE_FIELDS = {"name", "description", "owner", "plugins"}
SHARED_MARKETPLACE_ENTRY_FIELDS = {
    "name", "source", "version", "description", "displayName", "category", "homepage", "author",
}
SHARED_AUTHOR_FIELDS = {"name", "url", "email"}
ZCODE_MANIFEST_PART = PurePosixPath(ZCODE_MANIFEST_RELATIVE)
ZCODE_MARKETPLACE_PART = PurePosixPath(".claude-plugin/marketplace.json")
ZCODE_MARKETPLACE_NAME = re.compile(r"^[a-z0-9][a-z0-9._-]{0,127}$")
ZCODE_MARKETPLACE_CATEGORIES = {
    "developer-tools",
    "productivity",
    "utilities",
    "legal",
    "template",
    "finance",
    "other",
}
ZCODE_MIRRORED_MANIFEST_FIELDS = (
    "version",
    "description",
    "author",
    "homepage",
    "repository",
    "license",
    "keywords",
)

WORKBUDDY_MANIFEST_PART = PurePosixPath(CODEBUDDY_MANIFEST_RELATIVE)
WORKBUDDY_MARKETPLACE_PART = PurePosixPath(".codebuddy-plugin/marketplace.json")
WORKBUDDY_MARKETPLACE_NAME = re.compile(r"^[a-z0-9][a-z0-9._-]{0,127}$")
WORKBUDDY_CATEGORIES = {
    "education",
    "productivity",
    "developer-tools",
    "finance",
    "design",
    "research",
    "other",
}
WORKBUDDY_MIRRORED_MANIFEST_FIELDS = (
    "version",
    "description",
    "author",
    "homepage",
    "repository",
    "license",
    "keywords",
)
WORKBUDDY_FORBIDDEN_MANIFEST_KEYS = (
    "interface",
    "apps",
    "mcpServers",
    "hooks",
    "commands",
    "agents",
    "userConfig",
)

DETAILED_TUTOR_SKILLS = {
    "kaoyan-408-tutor",
    "kaoyan-math-coach",
    "kaoyan-english-coach",
    "kaoyan-politics-coach",
}

PORTABLE_RECORD_SKILLS = {
    "kaoyan-408-planner",
    "kaoyan-review-executor",
    "kaoyan-progress-diagnostician",
    "kaoyan-error-loop-coach",
    "kaoyan-mock-exam-coach",
}

EVIDENCE_SKILLS = set(EXPECTED_SKILLS)

OUTPUT_TAG_SKILLS = {
    "[用户材料]": {
        "kaoyan-error-loop-coach",
        "kaoyan-mock-exam-coach",
        "kaoyan-408-tutor",
        "kaoyan-math-coach",
        "kaoyan-english-coach",
        "kaoyan-politics-coach",
        "kaoyan-past-paper-analyst",
        "kaoyan-material-study-assistant",
    },
    "[原创练习]": {
        "kaoyan-error-loop-coach",
        "kaoyan-mock-exam-coach",
        "kaoyan-408-tutor",
        "kaoyan-math-coach",
        "kaoyan-english-coach",
        "kaoyan-politics-coach",
        "kaoyan-past-paper-analyst",
        "kaoyan-material-study-assistant",
    },
    "[官方核验]": {"kaoyan-official-info-researcher", "kaoyan-admissions-researcher"},
    "[网友评价]": {"kaoyan-admissions-researcher"},
    "[调研判断]": {"kaoyan-admissions-researcher"},
    "[待核验]": {"kaoyan-politics-coach", "kaoyan-official-info-researcher", "kaoyan-admissions-researcher"},
    "[真题证据]": {
        "kaoyan-408-tutor",
        "kaoyan-math-coach",
        "kaoyan-english-coach",
        "kaoyan-politics-coach",
        "kaoyan-past-paper-searcher",
        "kaoyan-past-paper-analyst",
    },
    "[真题未命中]": {
        "kaoyan-408-tutor",
        "kaoyan-math-coach",
        "kaoyan-english-coach",
        "kaoyan-politics-coach",
        "kaoyan-past-paper-searcher",
    },
}

LEGACY_PATTERNS = (
    re.compile(r"\b" + "bai" + r"du\b", re.IGNORECASE),
    re.compile(r"\bnet" + r"disk\b", re.IGNORECASE),
    re.compile(r"\blocal" + r"storage\b", re.IGNORECASE),
    re.compile(r"\bstudy" + r"-state\b", re.IGNORECASE),
)

SENSITIVE_PATTERNS = (
    re.compile(r"\bgh[pousr]_[A-Za-z0-9]{20,}\b"),
    re.compile(r"\bgithub_pat_[A-Za-z0-9_]{20,}\b"),
    re.compile(r"\bsk-[A-Za-z0-9_-]{20,}\b"),
    re.compile(r"\bfigd_[A-Za-z0-9_-]{20,}\b"),
    re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    re.compile(r"\bAIza[0-9A-Za-z_-]{30,}\b"),
    re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{10,}\b"),
    re.compile(r"\bnpm_[A-Za-z0-9]{20,}\b"),
    re.compile(r"\bglpat-[A-Za-z0-9_-]{20,}\b"),
    re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b"),
    re.compile(r"\baws[_ -]?secret[_ -]?access[_ -]?key\s*[:=]\s*[\"']?[A-Za-z0-9/+=]{30,}", re.IGNORECASE),
    re.compile(r"\bAccountKey\s*=\s*[A-Za-z0-9+/]{40,}={0,2}", re.IGNORECASE),
    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA |ENCRYPTED )?PRIVATE KEY-----"),
    re.compile(r"-----BEGIN PGP " + r"PRIVATE KEY BLOCK-----"),
    re.compile(
        r"\b(?:api[_ -]?key|access[_ -]?token|client[_ -]?secret|secret[_ -]?key|cookie)"
        r"\s*[:=]\s*[\"']?[^\s\"']{8,}",
        re.IGNORECASE,
    ),
)

HISTORY_SECRET_PATTERNS = (
    re.compile(rb"\bgh[pousr]_[A-Za-z0-9]{20,}\b"),
    re.compile(rb"\bgithub_pat_[A-Za-z0-9_]{20,}\b"),
    re.compile(rb"\bsk-[A-Za-z0-9_-]{20,}\b"),
    re.compile(rb"\bfigd_[A-Za-z0-9_-]{20,}\b"),
    re.compile(rb"\bAKIA[0-9A-Z]{16}\b"),
    re.compile(rb"\bAIza[0-9A-Za-z_-]{30,}\b"),
    re.compile(rb"\bxox[baprs]-[A-Za-z0-9-]{10,}\b"),
    re.compile(rb"\bnpm_[A-Za-z0-9]{20,}\b"),
    re.compile(rb"\bglpat-[A-Za-z0-9_-]{20,}\b"),
    re.compile(rb"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b"),
    re.compile(rb"\baws[_ -]?secret[_ -]?access[_ -]?key\s*[:=]\s*[\"']?[A-Za-z0-9/+=]{30,}", re.IGNORECASE),
    re.compile(rb"\bAccountKey\s*=\s*[A-Za-z0-9+/]{40,}={0,2}", re.IGNORECASE),
    re.compile(
        rb"\b(?:api[_ -]?key|access[_ -]?token|client[_ -]?secret|secret[_ -]?key|cookie)"
        rb"\s*[:=]\s*[\"']?[A-Za-z0-9+/=_-]{16,}",
        re.IGNORECASE,
    ),
    re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH |DSA |ENCRYPTED )?PRIVATE KEY-----"),
    re.compile(rb"-----BEGIN PGP " + rb"PRIVATE KEY BLOCK-----"),
)

HISTORY_LEGACY_PATTERNS = (
    re.compile(rb"\b" + b"bai" + rb"du\b", re.IGNORECASE),
    re.compile(rb"\bnet" + rb"disk\b", re.IGNORECASE),
    re.compile(rb"\blocal" + rb"storage\b", re.IGNORECASE),
    re.compile(rb"\bstudy" + rb"-state\b", re.IGNORECASE),
)


class UniqueKeyLoader(yaml.SafeLoader):
    """Safe YAML loader that rejects duplicate mapping keys."""


def _construct_unique_mapping(
    loader: UniqueKeyLoader, node: MappingNode, deep: bool = False
) -> dict[Any, Any]:
    mapping: dict[Any, Any] = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        if key in mapping:
            raise ConstructorError(
                "while constructing a mapping",
                node.start_mark,
                f"duplicate key: {key!r}",
                key_node.start_mark,
            )
        mapping[key] = loader.construct_object(value_node, deep=deep)
    return mapping


UniqueKeyLoader.add_constructor(
    yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
    _construct_unique_mapping,
)


def load_json(path: Path) -> Any:
    try:
        return json.loads(read_utf8_text(path))
    except json.JSONDecodeError as exc:
        raise ValidationError(f"invalid JSON: {path}: {exc}") from exc


def load_yaml(path: Path) -> Any:
    try:
        return yaml.load(read_utf8_text(path), Loader=UniqueKeyLoader)
    except (TypeError, yaml.YAMLError) as exc:
        raise ValidationError(f"invalid YAML: {path}: {exc}") from exc


def parse_frontmatter(path: Path) -> dict[str, Any]:
    text = read_utf8_text(path)
    lines = text.splitlines()
    require(lines and lines[0] == "---", f"missing YAML frontmatter: {path}")
    try:
        end = lines.index("---", 1)
    except ValueError as exc:
        raise ValidationError(f"unclosed YAML frontmatter: {path}") from exc
    require(any(line.strip() for line in lines[end + 1 :]), f"empty Skill body: {path}")
    try:
        metadata = yaml.load("\n".join(lines[1:end]), Loader=UniqueKeyLoader)
    except (TypeError, yaml.YAMLError) as exc:
        raise ValidationError(f"invalid YAML frontmatter: {path}: {exc}") from exc
    require(isinstance(metadata, dict), f"frontmatter must be a mapping: {path}")
    require(set(metadata) == {"name", "description"}, f"frontmatter must contain only name/description: {path}")
    require(all(isinstance(value, str) for value in metadata.values()), f"frontmatter values must be strings: {path}")
    return metadata


def check_manifest(plugin: Path) -> dict[str, Any]:
    manifest_path = plugin / ".codex-plugin" / "plugin.json"
    manifest = load_json(manifest_path)
    require(isinstance(manifest, dict), "plugin manifest must be an object")
    require(manifest.get("name") == "kaoyan-408", "manifest name must be kaoyan-408")
    version = manifest.get("version")
    require(isinstance(version, str) and SEMVER.fullmatch(version) is not None, "manifest version must be strict semver")
    require(manifest.get("skills") == "./skills/", "manifest skills path must be ./skills/")
    for key in ("apps", "mcpServers", "hooks"):
        require(key not in manifest, f"Skills-only manifest must not contain {key}")

    interface = manifest.get("interface")
    require(isinstance(interface, dict), "manifest is missing interface")
    require(interface.get("category") == "Education", "manifest category must be Education")
    require("screenshots" not in interface, "Skills-only manifest must not declare screenshots")
    prompts = interface.get("defaultPrompt")
    require(isinstance(prompts, list) and 1 <= len(prompts) <= 3, "defaultPrompt must contain 1 to 3 entries")
    require(
        all(isinstance(item, str) and 1 <= len(item) <= 128 for item in prompts),
        "each defaultPrompt must contain at most 128 characters",
    )
    for key in ("websiteURL", "privacyPolicyURL", "termsOfServiceURL"):
        require(str(interface.get(key, "")).startswith("https://"), f"{key} must be an HTTPS URL")
    for key in ("composerIcon", "logo"):
        relative = interface.get(key)
        require(isinstance(relative, str) and relative.startswith("./"), f"{key} must be a relative path")
        require((plugin / relative[2:]).is_file(), f"{key} target does not exist")
    return manifest


def check_codebuddy_manifest(plugin: Path, codex_manifest: dict[str, Any]) -> None:
    """Validate the WorkBuddy-native manifest mirrors the Codex manifest.

    WorkBuddy reads ``.codebuddy-plugin/plugin.json`` inside the installed plugin
    directory and resolves ``skills`` relative to that directory, so the manifest
    must stay inside the release tree and keep the Codex values in sync.
    """
    manifest = load_json(plugin / Path(*WORKBUDDY_MANIFEST_PART.parts))
    require(isinstance(manifest, dict), "WorkBuddy manifest must be an object")
    require(
        manifest.get("name") == plugin.name == codex_manifest.get("name"),
        "WorkBuddy manifest name must match the plugin directory and the Codex manifest",
    )
    for field in WORKBUDDY_MIRRORED_MANIFEST_FIELDS:
        require(
            manifest.get(field) == codex_manifest.get(field),
            f"WorkBuddy manifest field must stay identical to the Codex manifest: {field}",
        )
    require(manifest.get("skills") == "./skills", "WorkBuddy manifest skills path must be ./skills")
    require(
        (plugin / "skills").is_dir(),
        "WorkBuddy manifest skills directory does not exist",
    )
    category = manifest.get("category")
    require(
        isinstance(category, str) and category in WORKBUDDY_CATEGORIES,
        f"WorkBuddy manifest category is invalid: {category}",
    )
    for key in WORKBUDDY_FORBIDDEN_MANIFEST_KEYS:
        require(key not in manifest, f"Skills-only WorkBuddy manifest must not contain {key}")

def check_codebuddy_marketplace(repo: Path) -> None:
    """Validate the WorkBuddy marketplace descriptor published at the repository root.

    The descriptor points WorkBuddy at the shared plugin directory rather than
    duplicating the Skill tree, so the release payload stays the single source of
    truth for every host adapter.
    """
    marketplace = load_json(repo / Path(*WORKBUDDY_MARKETPLACE_PART.parts))
    require(isinstance(marketplace, dict), "WorkBuddy marketplace must be an object")
    name = marketplace.get("name")
    require(
        isinstance(name, str) and WORKBUDDY_MARKETPLACE_NAME.fullmatch(name) is not None,
        "WorkBuddy marketplace name is invalid",
    )
    description = marketplace.get("description")
    require(
        isinstance(description, str) and description.strip(),
        "WorkBuddy marketplace description must be a non-empty string",
    )
    owner = marketplace.get("owner")
    require(
        isinstance(owner, dict) and isinstance(owner.get("name"), str) and owner["name"].strip(),
        "WorkBuddy marketplace owner.name is required",
    )
    metadata = marketplace.get("metadata")
    require(
        isinstance(metadata, dict) and isinstance(metadata.get("version"), str) and metadata["version"].strip(),
        "WorkBuddy marketplace metadata.version is required",
    )
    plugins = marketplace.get("plugins")
    require(
        isinstance(plugins, list) and len(plugins) == 1,
        "WorkBuddy marketplace must contain exactly one plugin",
    )
    entry = plugins[0]
    require(isinstance(entry, dict), "WorkBuddy marketplace entry must be an object")
    require(entry.get("name") == "kaoyan-408", "WorkBuddy marketplace plugin name is invalid")
    require(
        entry.get("source") == "./plugins/kaoyan-408",
        "WorkBuddy marketplace source must be the relative plugin path",
    )
    manifest = load_json(
        repo / Path(*PLUGIN_RELATIVE_PATH.parts) / Path(*WORKBUDDY_MANIFEST_PART.parts)
    )
    require(
        entry.get("version") == manifest.get("version"),
        "WorkBuddy marketplace version must match the plugin manifest",
    )
    require(
        entry.get("category") == manifest.get("category"),
        "WorkBuddy marketplace category must match the plugin manifest",
    )
    require(
        entry.get("author") == manifest.get("author"),
        "WorkBuddy marketplace author must match the plugin manifest",
    )
    require(
        (repo / "plugins" / "kaoyan-408" / "skills").is_dir(),
        "WorkBuddy marketplace plugin skills directory does not exist",
    )


def check_claude_manifest(plugin: Path, codex_manifest: dict[str, Any]) -> None:
    """Keep Claude's native Skills-only adapter identical to the shared metadata."""
    manifest = load_json(plugin / Path(*CLAUDE_MANIFEST_PART.parts))
    require(isinstance(manifest, dict), "Claude manifest must be an object")
    require(
        manifest.get("name") == plugin.name == codex_manifest.get("name"),
        "Claude manifest name must match the plugin directory and the Codex manifest",
    )
    for key in CLAUDE_FORBIDDEN_MANIFEST_KEYS:
        require(key not in manifest, f"Skills-only Claude manifest must not contain {key}")
    require(
        set(manifest) == {"name", *CLAUDE_MIRRORED_MANIFEST_FIELDS},
        "Claude manifest must contain exactly the shared metadata and skills fields",
    )
    for field in CLAUDE_MIRRORED_MANIFEST_FIELDS:
        require(
            manifest[field] == codex_manifest.get(field),
            f"Claude manifest field must stay identical to the Codex manifest: {field}",
        )
    require(manifest["skills"] == "./skills/", "Claude manifest skills path must be ./skills/")
    require((plugin / "skills").is_dir(), "Claude manifest skills directory does not exist")


def check_claude_marketplace(repo: Path) -> None:
    """Check the Claude/ZCode marketplace intersection without executable fields."""
    marketplace = load_json(repo / Path(*ZCODE_MARKETPLACE_PART.parts))
    require(isinstance(marketplace, dict), "Claude marketplace must be an object")
    require(
        set(marketplace) == SHARED_MARKETPLACE_FIELDS,
        "shared marketplace must contain exactly the Claude/ZCode intersection fields",
    )
    require(marketplace.get("name") == "kaoyan-408", "Claude marketplace name is invalid")
    description = marketplace.get("description")
    require(isinstance(description, str) and description.strip(), "Claude marketplace description is required")
    owner = marketplace.get("owner")
    require(
        isinstance(owner, dict) and set(owner) <= SHARED_AUTHOR_FIELDS
        and isinstance(owner.get("name"), str) and owner["name"].strip(),
        "Claude marketplace owner must contain shared author fields and a name",
    )
    plugins = marketplace.get("plugins")
    require(isinstance(plugins, list) and len(plugins) == 1, "Claude marketplace must contain exactly one plugin")
    entry = plugins[0]
    require(isinstance(entry, dict), "Claude marketplace entry must be an object")
    require(
        set(entry) == SHARED_MARKETPLACE_ENTRY_FIELDS,
        "shared marketplace entry must contain exactly the Claude/ZCode intersection fields",
    )
    require(entry.get("name") == "kaoyan-408", "Claude marketplace plugin name is invalid")
    require(entry.get("source") == "./plugins/kaoyan-408", "Claude marketplace source must be the relative plugin path")
    manifest = load_json(repo / Path(*PLUGIN_RELATIVE_PATH.parts) / Path(*CLAUDE_MANIFEST_PART.parts))
    require(isinstance(manifest, dict), "Claude manifest must be an object")
    for field in ("version", "author", "homepage"):
        require(entry[field] == manifest.get(field), f"Claude marketplace {field} must match the plugin manifest")
    for field in ("description", "displayName"):
        require(isinstance(entry[field], str) and entry[field].strip(), f"Claude marketplace {field} is required")
    author = entry["author"]
    require(
        isinstance(author, dict) and set(author) <= SHARED_AUTHOR_FIELDS,
        "Claude marketplace author must contain only shared author fields",
    )
    category = entry["category"]
    require(
        isinstance(category, str) and category in ZCODE_MARKETPLACE_CATEGORIES,
        "shared marketplace category is invalid",
    )


def check_zcode_manifest(plugin: Path, codex_manifest: dict[str, Any]) -> None:
    """Validate the ZCode-native manifest mirrors the Codex manifest exactly."""
    manifest = load_json(plugin / Path(*ZCODE_MANIFEST_PART.parts))
    require(isinstance(manifest, dict), "ZCode manifest must be an object")
    require(
        manifest.get("name") == plugin.name == codex_manifest.get("name"),
        "ZCode manifest name must match the plugin directory and the Codex manifest",
    )
    for field in ZCODE_MIRRORED_MANIFEST_FIELDS:
        require(
            manifest.get(field) == codex_manifest.get(field),
            f"ZCode manifest field must stay identical to the Codex manifest: {field}",
        )
    require(manifest.get("skills") == "./skills/", "ZCode manifest skills path must be ./skills/")
    display_name = manifest.get("displayName")
    require(
        isinstance(display_name, str) and display_name.strip(),
        "ZCode manifest displayName must be a non-empty string",
    )
    for key in ("apps", "mcpServers", "hooks", "commands", "agents", "userConfig", "interface"):
        require(key not in manifest, f"Skills-only ZCode manifest must not contain {key}")


def check_zcode_marketplace(repo: Path) -> None:
    """Validate the ZCode marketplace descriptor published at the repository root."""
    marketplace = load_json(repo / Path(*ZCODE_MARKETPLACE_PART.parts))
    require(isinstance(marketplace, dict), "ZCode marketplace must be an object")
    name = marketplace.get("name")
    require(
        isinstance(name, str) and ZCODE_MARKETPLACE_NAME.fullmatch(name) is not None,
        "ZCode marketplace name is invalid",
    )
    owner = marketplace.get("owner")
    require(
        isinstance(owner, dict) and isinstance(owner.get("name"), str) and owner["name"].strip(),
        "ZCode marketplace owner.name is required",
    )
    plugins = marketplace.get("plugins")
    require(isinstance(plugins, list) and len(plugins) == 1, "ZCode marketplace must contain exactly one plugin")
    entry = plugins[0]
    require(isinstance(entry, dict), "ZCode marketplace entry must be an object")
    require(entry.get("name") == "kaoyan-408", "ZCode marketplace plugin name is invalid")
    require(
        entry.get("source") == "./plugins/kaoyan-408",
        "ZCode marketplace source must be the relative plugin path",
    )
    zcode_manifest = load_json(repo / Path(*PLUGIN_RELATIVE_PATH.parts) / Path(*ZCODE_MANIFEST_PART.parts))
    require(
        entry.get("version") == zcode_manifest.get("version"),
        "ZCode marketplace version must match the plugin manifest",
    )
    display_name = entry.get("displayName")
    require(
        isinstance(display_name, str) and display_name.strip(),
        "ZCode marketplace displayName must be a non-empty string",
    )
    require(
        entry.get("category") in ZCODE_MARKETPLACE_CATEGORIES,
        f"ZCode marketplace category is invalid: {entry.get('category')}",
    )


def check_skill(skill_dir: Path) -> None:
    name = skill_dir.name
    skill_path = skill_dir / "SKILL.md"
    content = read_utf8_text(skill_path)
    metadata = parse_frontmatter(skill_path)
    require(metadata["name"] == name, f"Skill name does not match directory: {name}")
    require(25 <= len(metadata["description"]) <= 1024, f"Skill description length is invalid: {name}")
    require(PLACEHOLDER not in content.upper(), f"Skill contains an unfinished placeholder: {name}")
    require("capability-routing-contract.md" in content, f"Skill does not load the routing contract: {name}")
    if name in EVIDENCE_SKILLS:
        require("evidence-copyright-contract.md" in content, f"Skill lacks conditional evidence contract loading: {name}")
    if name in PORTABLE_RECORD_SKILLS:
        require("portable-learning-records.md" in content, f"Skill lacks portable-record contract loading: {name}")
    for tag, skills in OUTPUT_TAG_SKILLS.items():
        if name in skills:
            require(tag in content, f"Skill does not require the output evidence tag {tag}: {name}")
    if name in DETAILED_TUTOR_SKILLS:
        require(
            "beginner-visual-answer-contract.md" in content,
            f"tutor Skill does not load the beginner answer contract: {name}",
        )
        for marker in ("每批最多四题", "只要答案", "最早易错点"):
            require(marker in content, f"tutor Skill is missing detailed-answer marker {marker}: {name}")

    yaml_path = skill_dir / "agents" / "openai.yaml"
    document = load_yaml(yaml_path)
    require(isinstance(document, dict) and set(document) == {"interface"}, f"openai.yaml root is invalid: {name}")
    interface = document.get("interface")
    required_fields = {"display_name", "short_description", "default_prompt"}
    require(isinstance(interface, dict) and set(interface) == required_fields, f"openai.yaml interface fields are invalid: {name}")
    require(all(isinstance(interface[field], str) for field in required_fields), f"openai.yaml values must be strings: {name}")
    require(25 <= len(interface["short_description"]) <= 64, f"short_description must contain 25 to 64 characters: {name}")
    require(f"${name}" in interface["default_prompt"], f"default_prompt must explicitly include ${name}")
    require(PLACEHOLDER not in read_utf8_text(yaml_path).upper(), f"openai.yaml contains a placeholder: {name}")


def check_links(plugin: Path) -> None:
    link_pattern = re.compile(r"\[[^\]]+\]\(([^)]+)\)")
    plugin_resolved = plugin.resolve()
    for md_path in plugin.rglob("*.md"):
        for target in link_pattern.findall(read_utf8_text(md_path)):
            clean = target.split("#", 1)[0].strip()
            if not clean or clean.startswith(("https://", "http://", "mailto:")):
                continue
            resolved = (md_path.parent / clean).resolve()
            require(
                resolved == plugin_resolved or plugin_resolved in resolved.parents,
                f"Markdown link leaves plugin tree: {md_path}: {target}",
            )
            require(resolved.exists(), f"Markdown link target does not exist: {md_path}: {target}")


def check_beginner_answer_contract(plugin: Path) -> None:
    contract = read_utf8_text(plugin / "references" / "beginner-visual-answer-contract.md")
    for marker in (
        "默认详细模式",
        "显式简洁覆盖",
        "每批最多四题",
        "不得省略中间步骤",
        "选择题必须逐项说明",
    ):
        require(marker in contract, f"beginner answer contract is missing marker: {marker}")
    for marker in (
        "题面完整性检查",
        "足以改变答案",
        "逐级提示",
        "独立作答",
        "考考我",
        "交卷前",
    ):
        require(marker in contract, f"beginner answer contract is missing teaching-mode marker: {marker}")


def check_learning_layer_contract(plugin: Path) -> None:
    contract = read_utf8_text(plugin / "references" / "learning-layer-contract.md")
    routing = read_utf8_text(plugin / "references" / "capability-routing-contract.md")
    require(
        "learning-layer-contract.md" in routing,
        "routing contract must load the generic learning-layer contract",
    )
    for capability in (
        "搜索",
        "计算",
        "词典",
        "卡片",
        "测验",
        "图谱",
        "媒体",
        "笔记",
        "文件",
        "定时任务",
    ):
        require(capability in contract, f"learning-layer contract is missing capability family: {capability}")
    for marker in (
        "只读",
        "本次不记忆",
        "禁止所有学习记录写入",
        "不要同步 Notion",
        "仅限制 Notion 写入",
        "宿主实际返回创建成功",
        "有实质变化",
    ):
        require(marker in contract, f"learning-layer contract is missing permission marker: {marker}")


def check_obsidian_brain_contract(plugin: Path) -> None:
    routing = read_utf8_text(plugin / "references" / "capability-routing-contract.md")
    brain = read_utf8_text(plugin / "references" / "obsidian-brain-contract.md")
    notion = read_utf8_text(plugin / "references" / "notion-brain-contract.md")
    require(
        "obsidian-brain-contract.md" in routing,
        "routing contract must load the Obsidian brain contract",
    )
    for marker in (
        ".codex/kaoyan-408/obsidian-brain.json",
        "读取用户要求参考的旧招生调研报告",
        '"schemaVersion": "1.1"',
        '"knowledgeRoot"',
        '"pastPaperRoot"',
        '"writeMode": "auto-structured"',
        '"retrievalScope": "project-first"',
        "[Obsidian记忆]",
        "本次不记忆",
        "未连接",
        "最多使用 8 篇笔记",
        "16,000",
        "hypothesis",
        "planned",
        "completed",
        "学习检查点.md",
        "政治",
    ):
        require(marker in brain, f"Obsidian brain contract is missing marker: {marker}")
    require(
        "notion-brain-contract.md" in routing,
        "routing contract must conditionally load the Notion brain contract",
    )
    for marker in (
        "kaoyan-408-brain:1.0",
        "update_content",
        "update_properties",
        "dedupeKey",
        "本次不记忆",
        "old_str",
        "new_str",
        "planned",
        "completed",
        "hypothesis",
        "06｜政治",
        "学习检查点",
    ):
        require(marker in notion, f"Notion brain contract is missing marker: {marker}")
    combined = "\n".join(
        read_utf8_text(path)
        for path in plugin.rglob("*")
        if path.is_file()
    )
    for private_marker in (
        "C:\\Users\\admin",
        "C:/Users/admin",
        "ob知识库",
    ):
        require(
            private_marker not in combined,
            f"public plugin contains a private local path marker: {private_marker}",
        )


def check_knowledge_points(plugin: Path) -> None:
    schema = load_json(plugin / "references" / "kp-408.schema.json")
    data = load_json(plugin / "references" / "kp-408.json")
    try:
        Draft202012Validator.check_schema(schema)
    except SchemaError as exc:
        raise ValidationError(f"invalid knowledge-point schema: {exc.message}") from exc
    errors = list(Draft202012Validator(schema, format_checker=FormatChecker()).iter_errors(data))
    require(not errors, f"invalid knowledge-point index: {errors[0].message if errors else ''}")
    points = data["knowledgePoints"]
    ids = [point["id"] for point in points]
    require(len(ids) == len(set(ids)), "knowledge-point IDs must be unique")
    prefixes = {"数据结构": "DS", "计算机组成原理": "CO", "操作系统": "OS", "计算机网络": "CN"}
    require({point["subject"] for point in points} == set(prefixes), "knowledge-point index must cover four 408 subjects")
    for point in points:
        require(point["id"].startswith(prefixes[point["subject"]] + "-"), "knowledge-point subject and ID prefix mismatch")


def check_portable_schema(plugin: Path) -> None:
    schema_path = plugin / "references" / "portable-learning-records.schema.json"
    schema = load_json(schema_path)
    require(isinstance(schema, dict), "portable record schema must be an object")
    require(schema.get("$schema") == "https://json-schema.org/draft/2020-12/schema", "portable record schema must use Draft 2020-12")
    try:
        Draft202012Validator.check_schema(schema)
    except SchemaError as exc:
        raise ValidationError(f"invalid portable-record JSON Schema: {exc.message}") from exc

    output_samples = (
        {
            "schemaVersion": "1.2",
            "recordType": "StudyProfile",
            "recordId": "kr-0f1e2d3c4b5a6978",
            "updatedAt": "2026-09-11",
            "targetExam": None,
            "targetDate": None,
            "weeklyHours": None,
            "currentPhase": None,
            "constraints": [],
        },
        {
            "schemaVersion": "1.1",
            "recordType": "ProgressSnapshot",
            "period": {"start": None, "end": None},
            "metrics": [],
            "accuracy": [],
            "blockers": [],
        },
        {
            "schemaVersion": "1.2",
            "recordType": "ReviewQueue",
            "recordId": "kr-1234567890abcdef",
            "updatedAt": None,
            "generatedAt": None,
            "items": [
                {
                    "subject": "408",
                    "topic": "Cache 映射",
                    "errorCause": None,
                    "errorCauseStatus": None,
                    "nextRetestDate": "2026-09-14",
                    "retestOffsetDays": None,
                    "retestAnchorDate": "2026-09-11",
                    "status": "pending",
                    "masteryEvidence": [],
                    "retestEvidence": [
                        {"evidenceType": "independent", "outcome": "correct", "date": None, "note": None}
                    ],
                }
            ],
        },
        {
            "schemaVersion": "1.2",
            "recordType": "SessionCheckpoint",
            "checkpointId": "kc-0f1e2d3c4b5a6978",
            "checkpointRevision": 1,
            "updatedAt": None,
            "currentTask": "2009-2018 阅读精读第二轮",
            "position": "英语二 2014 Text 2 第 3 题",
            "dueItems": ["kr-1234567890abcdef#1"],
            "pendingRetests": [],
        },
    )
    validator = Draft202012Validator(schema, format_checker=FormatChecker())
    for sample in output_samples:
        try:
            validator.validate(sample)
        except JsonSchemaValidationError as exc:
            raise ValidationError(f"portable-record schema rejects a required 1.1/1.2 shape: {exc.message}") from exc

    invalid_checkpoint_revision = {
        **output_samples[-1],
        "checkpointRevision": 0,
    }
    require(
        not validator.is_valid(invalid_checkpoint_revision),
        "portable-record schema must reject non-positive checkpoint revisions",
    )

    bad_evidence_type = {
        "schemaVersion": "1.2",
        "recordType": "ReviewQueue",
        "generatedAt": None,
        "items": [
            {
                "subject": None,
                "topic": "limit",
                "errorCause": None,
                "errorCauseStatus": None,
                "nextRetestDate": None,
                "retestOffsetDays": 3,
                "status": "pending",
                "masteryEvidence": [],
                "retestEvidence": [{"evidenceType": "guess", "outcome": "correct"}],
            }
        ],
    }
    require(
        not validator.is_valid(bad_evidence_type),
        "portable-record schema must reject unknown retestEvidence types",
    )

    defs = schema.get("$defs")
    require(isinstance(defs, dict) and "legacyInput" in defs, "portable-record schema must expose $defs/legacyInput")
    legacy_root = {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$ref": "#/$defs/legacyInput",
        "$defs": defs,
    }
    legacy_validator = Draft202012Validator(legacy_root, format_checker=FormatChecker())
    legacy_samples = (
        {
            "schemaVersion": "1.0",
            "period": {"start": "2026-07-01", "end": "2026-07-07"},
            "plannedUnits": 10,
            "completedUnits": 8,
            "accuracy": 0.7,
            "sampleSize": 20,
            "legacyExtension": "preserve me",
        },
        {
            "schemaVersion": "1.0",
            "items": [{"topic": "limit", "retestDate": "D+3"}],
        },
        {
            "schemaVersion": "1.0",
            "targetExam": "未提供",
            "targetDate": "",
            "weeklyHours": "unknown",
            "currentPhase": "",
            "constraints": [],
            "blockers": ["legacy extension that also resembles progress data"],
            "unrecognizedExtension": {"preserve": True},
        },
        {
            "schemaVersion": "1.1",
            "recordType": "ReviewQueue",
            "generatedAt": "2026-08-01",
            "items": [
                {
                    "subject": "数学二",
                    "topic": "泰勒展开",
                    "errorCause": None,
                    "errorCauseStatus": "hypothesis",
                    "nextRetestDate": None,
                    "retestOffsetDays": 5,
                    "status": "pending",
                    "masteryEvidence": [],
                }
            ],
        },
    )
    for sample in legacy_samples:
        try:
            legacy_validator.validate(sample)
        except JsonSchemaValidationError as exc:
            raise ValidationError(f"portable-record schema rejects a supported 1.0/1.1 input: {exc.message}") from exc
    require(
        all(not validator.is_valid(sample) for sample in legacy_samples[:3]),
        "portable-record root schema must reject all Schema 1.0 inputs",
    )
    invalid_11_date = {
        "schemaVersion": "1.1",
        "recordType": "ReviewQueue",
        "generatedAt": None,
        "items": [
            {
                "subject": None,
                "topic": "limit",
                "errorCause": None,
                "errorCauseStatus": None,
                "nextRetestDate": "D+3",
                "retestOffsetDays": None,
                "status": "pending",
                "masteryEvidence": [],
            }
        ],
    }
    require(
        not validator.is_valid(invalid_11_date),
        "portable-record schema must reject D+N in a Schema 1.1 date field",
    )
    invalid_date_and_offset = {
        **invalid_11_date,
        "items": [
            {
                **invalid_11_date["items"][0],
                "nextRetestDate": "2026-07-18",
                "retestOffsetDays": 3,
            }
        ],
    }
    require(
        not validator.is_valid(invalid_date_and_offset),
        "portable-record schema must reject simultaneous nextRetestDate and retestOffsetDays",
    )
    invalid_zero_total = {
        "schemaVersion": "1.1",
        "recordType": "ProgressSnapshot",
        "period": {"start": None, "end": None},
        "metrics": [],
        "accuracy": [
            {"subject": "math2", "correct": 1, "total": 0, "rate": None}
        ],
        "blockers": [],
    }
    require(
        not validator.is_valid(invalid_zero_total),
        "portable-record schema must reject correct > 0 when total is zero",
    )
    valid_accuracy_record = {
        "schemaVersion": "1.1",
        "recordType": "ProgressSnapshot",
        "period": {"start": None, "end": None},
        "metrics": [],
        "accuracy": [
            {"subject": "english2", "correct": 16, "total": 20, "rate": 0.8}
        ],
        "blockers": [],
    }
    check_progress_accuracy_semantics(valid_accuracy_record)
    semantic_mutations = (
        {"subject": "english2", "correct": 21, "total": 20, "rate": 1.0},
        {"subject": "english2", "correct": 16, "total": 20, "rate": 0.7},
    )
    for entry in semantic_mutations:
        record = {**valid_accuracy_record, "accuracy": [entry]}
        try:
            check_progress_accuracy_semantics(record)
        except ValidationError:
            continue
        raise ValidationError("portable-record semantic gate accepted inconsistent accuracy values")

    mastered_without_evidence = {
        "schemaVersion": "1.2",
        "recordType": "ReviewQueue",
        "generatedAt": None,
        "items": [
            {
                "subject": "408",
                "topic": "LRU 置换",
                "errorCause": None,
                "errorCauseStatus": None,
                "nextRetestDate": None,
                "retestOffsetDays": None,
                "status": "mastered",
                "masteryEvidence": [],
                "retestEvidence": [
                    {"evidenceType": "solution-seen", "outcome": "correct", "date": None, "note": None},
                    {"evidenceType": "redo-after-solution", "outcome": "correct", "date": None, "note": None},
                ],
            }
        ],
    }
    warnings = check_mastery_evidence_semantics(mastered_without_evidence)
    require(
        len(warnings) == 1 and "mastered" in warnings[0],
        "mastery evidence gate must flag mastered items without independent or transfer evidence",
    )
    qualified = {
        **mastered_without_evidence,
        "items": [
            {
                **mastered_without_evidence["items"][0],
                "retestEvidence": [
                    {"evidenceType": "independent", "outcome": "correct", "date": "2026-09-10", "note": None},
                    {"evidenceType": "transfer", "outcome": "correct", "date": None, "note": None},
                ],
            }
        ],
    }
    require(
        check_mastery_evidence_semantics(qualified) == [],
        "mastery evidence gate must accept independent plus transfer evidence",
    )


def check_progress_accuracy_semantics(record: dict[str, Any]) -> None:
    """Back-compat alias for the shared accuracy semantics gate."""
    check_accuracy_semantics(record)


def check_past_paper_schema(plugin: Path) -> None:
    schema = load_json(plugin / "references" / "past-paper-knowledge.schema.json")
    require(isinstance(schema, dict), "past-paper schema must be an object")
    try:
        Draft202012Validator.check_schema(schema)
    except SchemaError as exc:
        raise ValidationError(f"invalid past-paper JSON Schema: {exc.message}") from exc
    validator = Draft202012Validator(schema, format_checker=FormatChecker())
    source = {
        "schemaVersion": "1.0",
        "recordType": "PastPaperSource",
        "sourceId": "math1-2026-a",
        "subject": "数学一",
        "paperYear": 2026,
        "examDate": "2025-12-21",
        "paperType": "全国统考",
        "sourceUrl": "https://example.org/math1.pdf",
        "sourceKind": "official",
        "publisher": "example",
        "repository": None,
        "filePath": None,
        "commit": None,
        "license": "CC-BY-4.0",
        "retrievedAt": "2026-08-04T00:00:00Z",
        "contentSha256": "a" * 64,
        "completeness": "complete",
        "verificationStatus": "verified",
        "storagePolicy": "full-text",
    }
    validator.validate(source)
    require(
        validator.is_valid({**source, "subject": "政治"}),
        "past-paper schema must accept politics as the sixth searchable subject",
    )
    require(
        validator.is_valid({**source, "paperYear": 2027, "examDate": None}),
        "past-paper schema must accept future years without a hard upper cap",
    )
    for mutation in (
        {**source, "subject": "数学三"},
        {**source, "paperYear": 2009},
        {**source, "sourceUrl": "http://example.org/paper"},
    ):
        require(not validator.is_valid(mutation), "past-paper schema accepted an out-of-scope source")


def check_release_tree(plugin: Path) -> None:
    roots = {path.name for path in plugin.iterdir()}
    require(roots == ALLOWED_PLUGIN_ROOTS, f"plugin roots do not match the release allowlist: {sorted(roots)}")

    for path in plugin.rglob("*"):
        require(not path.is_symlink(), f"release tree must not contain symbolic links: {path}")

    actual_files = {
        path.relative_to(plugin).as_posix()
        for path in plugin.rglob("*")
        if path.is_file()
    }
    require(actual_files == ALLOWED_RELEASE_FILES, "release tree does not match the exact full-path allowlist")

    for relative in sorted(actual_files):
        pure = PurePosixPath(relative)
        require(not ({part.lower() for part in pure.parts} & FORBIDDEN_PATH_PARTS), f"forbidden release path: {relative}")
        text = read_utf8_text(plugin / Path(*pure.parts))
        require(PLACEHOLDER not in text.upper(), f"release file contains an unfinished placeholder: {relative}")
        for pattern in LEGACY_PATTERNS:
            require(pattern.search(text) is None, f"release file contains a removed-system marker: {relative}")
        for pattern in SENSITIVE_PATTERNS:
            require(pattern.search(text) is None, f"release file contains a likely secret: {relative}")


def check_forward_cases(repo: Path) -> None:
    forward = load_json(repo / "tests" / "forward-cases.json")
    require(isinstance(forward, dict) and forward.get("schemaVersion") == "2.0", "forward cases must use schemaVersion 2.0")
    cases = forward.get("cases")
    require(isinstance(cases, list) and len(cases) >= len(EXPECTED_SKILLS), "forward cases must cover at least one case per Skill")
    ids = [case.get("id") for case in cases if isinstance(case, dict)]
    require(len(ids) == len(cases) and len(set(ids)) == len(ids) and all(isinstance(item, str) and item for item in ids), "forward case IDs must be unique non-empty strings")
    routed: set[str] = set()
    for case in cases:
        require(isinstance(case, dict), "each forward case must be an object")
        skill = case.get("skillUnderTest")
        kind = case.get("kind")
        require(skill in EXPECTED_SKILLS, f"forward case contains an unknown Skill: {case.get('id')}")
        require(kind in {"positive", "colloquial", "conflict", "compound"}, f"forward case kind is invalid: {case.get('id')}")
        require(case.get("expectedPrimary") in EXPECTED_SKILLS, f"forward case route is invalid: {case.get('id')}")
        require(isinstance(case.get("prompt"), str) and case["prompt"].strip(), f"forward case has no prompt: {case.get('id')}")
        require(isinstance(case.get("expectedBehavior"), list) and case["expectedBehavior"], f"forward case has no behavior assertions: {case.get('id')}")
        require(
            all(isinstance(item, str) and item.strip() for item in case["expectedBehavior"]),
            f"forward behavior assertions must be non-empty strings: {case.get('id')}",
        )
        if kind in {"positive", "colloquial"}:
            require(case["expectedPrimary"] == skill, f"{kind} case does not route to the Skill under test: {case.get('id')}")
        elif kind == "conflict":
            require(case.get("expectedNotPrimary") == skill, f"conflict case does not exclude the Skill under test: {case.get('id')}")
            require(case["expectedPrimary"] != skill, f"conflict case still routes to the excluded Skill: {case.get('id')}")
        routed.add(skill)
    require(routed == EXPECTED_SKILLS, "forward cases must cover every Skill with at least one case")


def check_behavior_cases(repo: Path) -> None:
    behavior = load_json(repo / "tests" / "behavior-cases.json")
    require(isinstance(behavior, dict) and behavior.get("schemaVersion") == "2.0", "behavior cases must use schemaVersion 2.0")
    cases = behavior.get("cases")
    require(isinstance(cases, list) and len(cases) >= len(EXPECTED_SKILLS), "behavior cases must cover at least one scenario per Skill")
    ids: list[str] = []
    for case in cases:
        require(isinstance(case, dict), "each behavior case must be an object")
        case_id = case.get("id")
        require(isinstance(case_id, str) and case_id.strip(), "behavior case ID must be a non-empty string")
        ids.append(case_id)
        require(case.get("expectedPrimary") in EXPECTED_SKILLS, f"behavior case route is invalid: {case_id}")
        has_prompt = isinstance(case.get("prompt"), str) and bool(case["prompt"].strip())
        has_turns = isinstance(case.get("turns"), list) and bool(case["turns"])
        has_transcript = isinstance(case.get("transcript"), list) and bool(case["transcript"])
        require(
            has_prompt or has_turns or has_transcript,
            f"behavior case must contain prompt, turns, or transcript: {case_id}",
        )
        rubric = case.get("rubric")
        require(isinstance(rubric, list) and bool(rubric), f"behavior case must contain a non-empty rubric list: {case_id}")
        require(
            all(isinstance(item, str) and item.strip() for item in rubric),
            f"behavior rubric entries must be non-empty strings: {case_id}",
        )
        if has_transcript:
            for turn in case["transcript"]:
                require(isinstance(turn, dict), f"behavior transcript turn must be an object: {case_id}")
                require(turn.get("role") in {"user", "assistant"}, f"behavior transcript role is invalid: {case_id}")
                require(
                    isinstance(turn.get("content"), str) and turn["content"].strip(),
                    f"behavior transcript content is empty: {case_id}",
                )
    require(len(ids) == len(set(ids)), "behavior case IDs must be unique")


def check_repository_docs(repo: Path) -> None:
    required = {
        "README.md",
        "CHANGELOG.md",
        "LICENSE",
        "PRIVACY.md",
        "TERMS.md",
        "SECURITY.md",
        "THIRD_PARTY_CONTENT.md",
        "QUALITY_GATES.md",
        ".agents/plugins/marketplace.json",
        ".claude-plugin/marketplace.json",
        ".codebuddy-plugin/marketplace.json",
        "tests/forward-cases.json",
        "tests/behavior-cases.json",
        "tests/system-validator-evidence.json",
    }
    for relative in required:
        require((repo / relative).is_file(), f"required repository file is missing: {relative}")
    require(not (repo / "submission").exists(), "obsolete submission directory must be absent")

    manifest = load_json(
        repo / Path(*PLUGIN_RELATIVE_PATH.parts) / ".codex-plugin" / "plugin.json"
    )
    version = manifest.get("version") if isinstance(manifest, dict) else None
    require(
        isinstance(version, str) and SEMVER.fullmatch(version) is not None,
        "manifest version is unavailable for documentation checks",
    )
    readme = read_utf8_text(repo / "README.md")
    require(
        f"当前版本：`{version}`" in readme,
        "README current version must match plugin.json.version",
    )
    require(
        f"--ref v{version}" in readme,
        "README marketplace ref must match plugin.json.version",
    )
    require(
        f"--branch v{version}" in readme,
        "README clone tag must match plugin.json.version",
    )
    changelog = read_utf8_text(repo / "CHANGELOG.md")
    current_release = re.search(
        r"^## \[([^\]]+)\] - (Unreleased|\d{4}-\d{2}-\d{2})$",
        changelog,
        re.MULTILINE,
    )
    require(current_release is not None, "CHANGELOG must start with a versioned release heading")
    require(
        current_release.group(1) == version,
        "CHANGELOG current version must match plugin.json.version",
    )

    marketplace = load_json(repo / ".agents" / "plugins" / "marketplace.json")
    require(isinstance(marketplace, dict) and marketplace.get("name") == "kaoyan-408", "marketplace name is invalid")
    plugins = marketplace.get("plugins")
    require(isinstance(plugins, list) and len(plugins) == 1, "marketplace must contain exactly one plugin")
    entry = plugins[0]
    require(isinstance(entry, dict) and entry.get("name") == "kaoyan-408", "marketplace plugin name is invalid")
    require(entry.get("category") == "Education", "marketplace category must be Education")
    require(entry.get("source", {}).get("path") == "./plugins/kaoyan-408", "marketplace source.path is invalid")
    require(entry.get("policy", {}).get("installation") == "AVAILABLE", "marketplace installation policy is invalid")
    require(entry.get("policy", {}).get("authentication") == "ON_INSTALL", "marketplace authentication policy is invalid")
    check_zcode_marketplace(repo)
    check_claude_marketplace(repo)
    check_codebuddy_marketplace(repo)

    check_cursor_marketplace(repo, manifest)


def check_cursor_marketplace(repo: Path, manifest: dict[str, Any]) -> None:
    """Cursor discovers this repo from root manifests and reuses the Codex skill tree."""
    cursor_dir = repo / ".cursor-plugin"
    marketplace_path = cursor_dir / "marketplace.json"
    plugin_path = cursor_dir / "plugin.json"
    require(marketplace_path.is_file(), "Cursor marketplace is missing: .cursor-plugin/marketplace.json")
    require(plugin_path.is_file(), "Cursor plugin manifest is missing: .cursor-plugin/plugin.json")
    cursor_marketplace = load_json(marketplace_path)
    cursor_plugin = load_json(plugin_path)
    version = manifest.get("version")

    require(isinstance(cursor_marketplace, dict), "Cursor marketplace must be an object")
    require(cursor_marketplace.get("name") == "kaoyan-408", "Cursor marketplace name is invalid")
    owner = cursor_marketplace.get("owner")
    require(isinstance(owner, dict) and owner.get("name") == "yq6666-66", "Cursor marketplace owner is invalid")
    plugins = cursor_marketplace.get("plugins")
    require(isinstance(plugins, list) and len(plugins) == 1, "Cursor marketplace must contain exactly one plugin")
    entry = plugins[0]
    require(isinstance(entry, dict), "Cursor marketplace plugin entry must be an object")
    require(entry.get("name") == "kaoyan-408", "Cursor marketplace plugin name is invalid")
    require(entry.get("source") == "./", "Cursor marketplace source must be the repository root")
    require(
        set(entry) <= {"name", "source", "description", "minClientVersions"},
        "Cursor marketplace entry has fields the official schema rejects",
    )

    require(isinstance(cursor_plugin, dict), "Cursor plugin manifest must be an object")
    require(cursor_plugin.get("name") == "kaoyan-408", "Cursor plugin name is invalid")
    require(cursor_plugin.get("version") == version, "Cursor plugin version must match plugin.json.version")
    require(cursor_plugin.get("category") == "Education", "Cursor plugin category must be Education")
    for key in ("mcpServers", "hooks", "rules", "commands", "agents", "apps", "userConfig"):
        require(key not in cursor_plugin, f"Cursor manifest must not declare {key}")
    skills = cursor_plugin.get("skills")
    require(skills == "plugins/kaoyan-408/skills", "Cursor skills path is invalid")
    skill_root = repo / "plugins" / "kaoyan-408" / "skills"
    require(skill_root.is_dir(), "Cursor skills directory does not exist")
    skill_names = {
        path.name
        for path in skill_root.iterdir()
        if path.is_dir() and (path / "SKILL.md").is_file()
    }
    require(skill_names == EXPECTED_SKILLS, "Cursor skills directory must match the released Skill set")
    logo = "plugins/kaoyan-408/assets/kaoyan-408.svg"
    require(cursor_plugin.get("logo") == logo, "Cursor logo path is invalid")
    require((repo / logo).is_file(), "Cursor logo file does not exist")


def _run_git(repo: Path, arguments: list[str], *, input_bytes: bytes | None = None) -> subprocess.CompletedProcess[bytes]:
    try:
        result = subprocess.run(
            ["git", *arguments],
            cwd=repo,
            input=input_bytes,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )
    except OSError as exc:
        raise ValidationError(f"cannot run git: {exc}") from exc
    require(result.returncode == 0, f"git {' '.join(arguments)} failed: {result.stderr.decode('utf-8', 'replace').strip()}")
    return result


def check_git_history(repo: Path) -> None:
    objects_output = _run_git(repo, ["rev-list", "--objects", "--all"]).stdout.decode("utf-8", "strict")
    object_paths: dict[str, str] = {}
    object_ids: list[str] = []
    for line in objects_output.splitlines():
        object_id, _, path = line.partition(" ")
        if object_id and object_id not in object_paths:
            object_ids.append(object_id)
            object_paths[object_id] = path
        if path:
            parts = {part.lower() for part in PurePosixPath(path).parts}
            require(not (parts & HISTORY_FORBIDDEN_PATH_PARTS), f"Git history contains a removed private-data path: {path}")
            encoded_path = path.encode("utf-8")
            for pattern in HISTORY_SECRET_PATTERNS:
                require(pattern.search(encoded_path) is None, f"Git history contains a likely secret in a path: {path}")

    if not object_ids:
        return
    batch = _run_git(repo, ["cat-file", "--batch"], input_bytes=("\n".join(object_ids) + "\n").encode("ascii")).stdout
    stream = io.BytesIO(batch)
    for requested_id in object_ids:
        header = stream.readline().rstrip(b"\n")
        fields = header.split()
        require(len(fields) >= 3, f"unexpected git cat-file response for {requested_id}")
        object_type = fields[1]
        size = int(fields[2])
        payload = stream.read(size)
        require(len(payload) == size and stream.read(1) == b"\n", f"truncated git object: {requested_id}")
        path = object_paths.get(requested_id, "")
        if object_type in {b"blob", b"commit", b"tag"}:
            for pattern in HISTORY_SECRET_PATTERNS:
                require(pattern.search(payload) is None, f"Git history contains a likely secret in {path or requested_id}")
        if object_type == b"blob" and path not in {".semgrep.yml", "scripts/validate_repository.py"}:
            for pattern in HISTORY_LEGACY_PATTERNS:
                require(pattern.search(payload) is None, f"Git history contains a removed-system marker in {path or requested_id}")


def validate_repo(
    repo: Path | None = None,
    *,
    scan_history: bool = True,
) -> list[str]:
    repo = (repo or Path(__file__).resolve().parents[1]).resolve()
    plugin = repo / Path(*PLUGIN_RELATIVE_PATH.parts)
    require(plugin.is_dir(), f"plugin directory does not exist: {plugin}")

    check_repository_docs(repo)
    manifest = check_manifest(plugin)
    check_zcode_manifest(plugin, manifest)
    check_claude_manifest(plugin, manifest)
    check_codebuddy_manifest(plugin, manifest)
    check_release_tree(plugin)
    check_obsidian_brain_contract(plugin)
    check_learning_layer_contract(plugin)
    check_beginner_answer_contract(plugin)
    check_portable_schema(plugin)
    check_past_paper_schema(plugin)
    check_knowledge_points(plugin)

    skill_root = plugin / "skills"
    skill_dirs = {path.name: path for path in skill_root.iterdir() if path.is_dir()}
    require(set(skill_dirs) == EXPECTED_SKILLS, "Skill set must match the declared design")
    for name in sorted(EXPECTED_SKILLS):
        check_skill(skill_dirs[name])
    check_links(plugin)
    check_forward_cases(repo)
    check_behavior_cases(repo)
    if scan_history:
        check_git_history(repo)
    return [
        "manifest and marketplace",
        f"{len(EXPECTED_SKILLS)} Skills and openai.yaml files",
        "shared contracts, generic learning layers, dual brains, teaching modes, portable-record and past-paper JSON Schemas",
        "exact release allowlist, UTF-8/LF, and sensitive-content scan",
        "routing and behavior scenario coverage checks",
        "Git-history, secret, and removed-system scans",
    ]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.parse_args()
    try:
        results = validate_repo()
    except (OSError, UnicodeError, ValidationError) as exc:
        print(f"[FAIL] {exc}", file=sys.stderr)
        return 1
    for result in results:
        print(f"[OK] {result}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
